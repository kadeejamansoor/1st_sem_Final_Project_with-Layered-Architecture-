package lk.ijse.projectseaw.model;

import lk.ijse.projectseaw.db.DBConnection;
import lk.ijse.projectseaw.dto.RoomStatus;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class RoomStatusModel {

    public static List<RoomStatus> getAll() throws SQLException, ClassNotFoundException {
        /*ResultSet set= CrudUtil.crudUtil("SELECT * from room");
        ArrayList<RoomTm>list=new ArrayList<>();
        RoomTm tm=null;
        while (set.next()){
            tm=new RoomTm();
            tm.setRoomId(set.getString(1));
            tm.setRoom_type(set.getString(2));
            tm.setGuestId(set.getString(3));
            tm.setFloor(set.getString(4));
            tm.setCapacity(set.getString(5));
            tm.setRate(set.getString(6));

            list.add(tm);
        }
        System.gc();
        return list;*/

            Connection con = DBConnection.getInstance().getConnection();
            String sql = "SELECT * FROM RoomStatus";

            List<RoomStatus> data = new ArrayList<>();

            ResultSet resultSet = con.createStatement().executeQuery(sql);
            while (resultSet.next()) {
                data.add(new RoomStatus(
                        resultSet.getString(1),
                        resultSet.getString(2),
                        resultSet.getInt(3),
                        resultSet.getInt(4),
                        resultSet.getDouble(5),
                        resultSet.getString(6),
                        resultSet.getString(7)
                ));
            }
            return data;
        }

        public static List<String> loadIds() throws SQLException, ClassNotFoundException {
            Connection con = DBConnection.getInstance().getConnection();
            ResultSet resultSet = con.createStatement().executeQuery("SELECT id FROM RoomStatus");

            List<String> data = new ArrayList<>();

            while (resultSet.next()) {
                data.add(resultSet.getString(1));
            }
            return data;
        }

        public static RoomStatus searchById(String id) throws SQLException, ClassNotFoundException {
            Connection con = DBConnection.getInstance().getConnection();

            PreparedStatement pstm = con.prepareStatement("SELECT * FROM RoomStatus WHERE id = ?");
            pstm.setString(1, id);

            ResultSet resultSet = pstm.executeQuery();
            if(resultSet.next()) {
                return  new RoomStatus(
                        resultSet.getString(1),
                        resultSet.getString(2),
                        resultSet.getInt(3),
                        resultSet.getInt(4),
                        resultSet.getDouble(5),
                        resultSet.getString(6),
                        resultSet.getString(7)
                );
            }
            return null;
        }
    }

