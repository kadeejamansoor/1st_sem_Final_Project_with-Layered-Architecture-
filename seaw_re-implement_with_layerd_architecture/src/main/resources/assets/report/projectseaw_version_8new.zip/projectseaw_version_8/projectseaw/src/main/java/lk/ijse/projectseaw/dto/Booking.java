package lk.ijse.projectseaw.dto;

import lombok.*;

import java.sql.Date;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString

public class Booking {
    private String bookingId;
    private String BookingCheckIn;
    private String BookingCheckOut;
    private int BookingGuests;
    private String BookingSelectRoom;
    private String BookingGuestId;


}
