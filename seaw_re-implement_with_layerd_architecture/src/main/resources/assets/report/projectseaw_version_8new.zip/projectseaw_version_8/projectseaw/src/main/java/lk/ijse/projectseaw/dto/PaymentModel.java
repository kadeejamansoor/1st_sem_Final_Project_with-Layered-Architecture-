package lk.ijse.projectseaw.dto;

import lk.ijse.projectseaw.util.CrudUtil;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class PaymentModel {
    public static ArrayList<String> getAllIds() throws SQLException, ClassNotFoundException {
        ArrayList<String>ids=new ArrayList<>();
        ResultSet set= CrudUtil.crudUtil("SELECT payment_id FROM payment");
        while (set.next()){
            ids.add(set.getString(1));
        }
        return ids;
    }

    public static Payment get(String id) throws SQLException, ClassNotFoundException {
       ResultSet resultSet= CrudUtil.crudUtil("SELECT * From payment where payment_id=? ",id);
       Payment payment=new Payment();
       while (resultSet.next()){
payment.setPayment_id(resultSet.getString(1));
payment.setBooking_id(resultSet.getString(2));
payment.setGuest_id(resultSet.getString(3));
payment.setAmount(resultSet.getString(4));
payment.setPayment_date(resultSet.getString(5));
payment.setPayment_type(resultSet.getString(6));
       }
       return payment;
    }
}
