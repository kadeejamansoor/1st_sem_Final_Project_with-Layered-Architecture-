package lk.ijse.projectseaw.model;

import lk.ijse.projectseaw.db.DBConnection;
import lk.ijse.projectseaw.dto.Guest;
import lk.ijse.projectseaw.dto.Stock;

import java.lang.reflect.InvocationTargetException;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

public class GuestModel {
    private static final String URL = "jdbc:mysql://localhost:3306/seew";
    private static final Properties props = new Properties();

    static {
        props.setProperty("user", "root");
        props.setProperty("password", "1234");
    }

    public static List<Guest> getAll() throws SQLException, ClassNotFoundException {
        Connection con = DBConnection.getInstance().getConnection();
        String sql = "SELECT * FROM Guest";

        List<Guest> data = new ArrayList<>();

        ResultSet resultSet = con.createStatement().executeQuery(sql);
        while (resultSet.next()) {
            data.add(new Guest(
                    resultSet.getString(1),
                    resultSet.getString(2),
                    resultSet.getString(3),
                    resultSet.getString(4),
                    resultSet.getString(5),
                    resultSet.getString(6),
                    resultSet.getString(7),
                    resultSet.getInt(8)
            ));
        }
        return data;
    }



    public static boolean save(Guest guest) throws SQLException {
        try (Connection con = DriverManager.getConnection(URL, props)) {
            String sql = "INSERT INTO Guest(guest_id, guest_Fullname, address, city, postal_code, country, state, age) " +
                    "VALUES(?, ?, ?, ?, ?, ?, ?, ?)";

            PreparedStatement pstm = con.prepareStatement(sql);
            pstm.setString(1, guest.getGuestId());
            pstm.setString(2, guest.getFullname());
            pstm.setString(1, guest.getAddress());
            pstm.setString(2, guest.getCity());
            pstm.setString(1, guest.getPostalcode());
            pstm.setString(2, guest.getCountry());
            pstm.setString(3, guest.getState());
            pstm.setInt(3, guest.getAge());

            return pstm.executeUpdate() > 0;
        }
    }

    public static boolean update(String guestId, String fullName, String address, String city, String postalCode, String country, String state, int age) throws SQLException {
        try (Connection con = DriverManager.getConnection(URL, props);
             PreparedStatement pstm = con.prepareStatement("UPDATE Guest SET guest_Fullname = ?, address = ?, city = ?, postal_code = ?, country = ?, state = ?, age = ? WHERE guest_id = ?")) {

            pstm.setString(1, fullName);
            pstm.setString(2, address);
            pstm.setString(3, city);
            pstm.setString(4, postalCode);
            pstm.setString(5, country);
            pstm.setString(6, state);
            pstm.setInt(7, age);
            pstm.setString(8, guestId);

            int rowsAffected = pstm.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            // Handle any SQL exceptions
            e.printStackTrace();
            throw e;
        }
    }


    public static boolean delete(String GuestId) throws SQLException {
        try (Connection con = DriverManager.getConnection(URL, props)) {
            String sql = "DELETE FROM Guest WHERE guest_id = ?";
            PreparedStatement pstm = con.prepareStatement(sql);
            pstm.setString(1, GuestId);

            return pstm.executeUpdate() > 0;
        }
    }
}
