package lk.ijse.projectseaw.dto.tm;

import lombok.*;

import java.sql.Date;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString

public class BookingTm {
    private String bookingId;
    private String BookingCheckIn;
    private String BookingCheckOut;
    private int BookingGuests;
    private String BookingSelectRoom;
    private String BookingGuestId;


    public BookingTm(String bookingId, Date checkIn, Date checkOut, int guests, String selectRoom, String guestId) {
    }
}
