package lk.ijse.projectseaw.dto;

import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString

public class RoomStatus {
    private String roomId;
    private String roomType;
    private int floorNumber;
    private int capacity;
    private double rate;
    private String status;
    private String guestId;




}
