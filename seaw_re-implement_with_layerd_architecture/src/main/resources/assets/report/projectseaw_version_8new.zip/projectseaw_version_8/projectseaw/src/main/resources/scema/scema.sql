DROP DATABASE IF EXISTS Seew;
CREATE DATABASE IF NOT EXISTS Seew;
USE Seew;

-- Employee table
DROP TABLE IF EXISTS Employee;
CREATE TABLE IF NOT EXISTS Employee (
    empid VARCHAR(15) NOT NULL,
    name VARCHAR(50),
    contact VARCHAR(100),
    address VARCHAR(100),
    role VARCHAR(100),
    CONSTRAINT PRIMARY KEY (empid)
    );

-- User table
DROP TABLE IF EXISTS User;
CREATE TABLE IF NOT EXISTS User (
    username VARCHAR(50) NOT NULL,
    password VARCHAR(50) NOT NULL
    );


-- Salary table
DROP TABLE IF EXISTS Salary;
CREATE TABLE IF NOT EXISTS Salary (
    salary_id VARCHAR(15) NOT NULL,
    fullName VARCHAR(15),
    amount DOUBLE,
    date VARCHAR(15),
    employee_id VARCHAR(15),
    CONSTRAINT PRIMARY KEY (salary_id),
    CONSTRAINT FOREIGN KEY (employee_id) REFERENCES Employee(empid) on Delete Cascade on Update Cascade
    );



-- Stock table
DROP TABLE IF EXISTS Stock;
CREATE TABLE IF NOT EXISTS Stock (
    stock_id VARCHAR(15) NOT NULL,
    stock_name VARCHAR(50),
    quantity INT,
    CONSTRAINT PRIMARY KEY (stock_id)
    );


-- Guest table
DROP TABLE IF EXISTS Guest;
CREATE TABLE IF NOT EXISTS Guest (
    guest_id VARCHAR(15) NOT NULL,
    guest_Fullname VARCHAR(50),
    address VARCHAR(50),
    city VARCHAR(50),
    postal_code VARCHAR(50),
    country VARCHAR(50),
    state VARCHAR(50),
    age int,
    CONSTRAINT PRIMARY KEY (guest_id)
    );


-- Booking table
DROP TABLE IF EXISTS Booking;
CREATE TABLE IF NOT EXISTS Booking (
    booking_id VARCHAR(15),
    check_in DATE,
    check_out DATE,
    no_of_guest int,
    select_room VARCHAR(15),
    guest_id VARCHAR(15),
    CONSTRAINT PRIMARY KEY (booking_id),
    CONSTRAINT FOREIGN KEY (guest_id) REFERENCES Guest(guest_id)  on Delete Cascade on Update Cascade
    );




-- Room table
DROP TABLE IF EXISTS Room;
CREATE TABLE IF NOT EXISTS Room (
    room_id VARCHAR(15) NOT NULL,
    room_type VARCHAR(50),
    floor_Number INT,
    capacity INT,
    rate double
    );

DROP TABLE IF EXISTS RoomStatus;
CREATE TABLE IF NOT EXISTS RoomStatus (
     room_id VARCHAR(15) NOT NULL,
     room_type VARCHAR(50),
     floor_Number INT,
     capacity INT,
     rate double,
     room_status VARCHAR(50),
     guest_id VARCHAR(50),
     CONSTRAINT PRIMARY KEY (room_id),
     CONSTRAINT FOREIGN KEY (guest_id) REFERENCES Guest(guest_id) on Delete Cascade on Update Cascade
);



-- Reservation table
DROP TABLE IF EXISTS Reservation;
CREATE TABLE IF NOT EXISTS Reservation (
    reservation_id VARCHAR(15) NOT NULL,
    room_type VARCHAR(50),
    room_id VARCHAR(15),
    CONSTRAINT PRIMARY KEY (reservation_id),
    CONSTRAINT FOREIGN KEY (room_id) REFERENCES RoomStatus(room_id) on Delete Cascade on Update Cascade
    );

-- Booking-Room association table
DROP TABLE IF EXISTS Booking_Room;
CREATE TABLE IF NOT EXISTS Booking_Room (
    room_id VARCHAR(15) NOT NULL,
    booking_id VARCHAR(50),
    CONSTRAINT PRIMARY KEY (room_id , booking_id),
    CONSTRAINT FOREIGN KEY (room_id) REFERENCES RoomStatus(room_id) on Delete Cascade on Update Cascade,
    CONSTRAINT FOREIGN KEY (booking_id) REFERENCES Booking(booking_id)  on Delete Cascade on Update Cascade
    );

-- Payment table
DROP TABLE IF EXISTS Payment;
CREATE TABLE IF NOT EXISTS Payment (
    payment_id VARCHAR(50),
    booking_id VARCHAR(25),
    guest_id VARCHAR(25),
    amount DOUBLE,
    Payment_date DATE,
    CONSTRAINT PRIMARY KEY (payment_id),
    CONSTRAINT FOREIGN KEY (booking_id) REFERENCES Booking(booking_id) on Delete Cascade on Update Cascade,
    CONSTRAINT FOREIGN KEY (guest_id) REFERENCES Guest(guest_id) on Delete Cascade on Update Cascade
    );






INSERT INTO Employee VALUES('e001', 'Nuwan Perera', '+94 77 123 4567', 'Colombo', 'worker');
INSERT INTO Employee VALUES('e002', 'Samantha Silva', '+94 76 234 5678', '456 Kandy Road, Gampaha', 'manager');
INSERT INTO Employee VALUES('e003', 'Chathura Rajapakse', '+94 71 345 6789', '789 Negombo Road, Wattala', 'worker');
INSERT INTO Employee VALUES('e004', 'Priyanka Fernando', '+94 77 456 7890', '321 Colombo Road, Nugegoda', 'receptionist');
INSERT INTO Employee VALUES('e005', 'Kamal Jayawardena', '+94 76 567 8901', '654 Galle Face Road, Colombo', 'worker');
INSERT INTO Employee VALUES('e006', 'Anusha Gunathilake', '+94 71 678 9012', '987 Colombo Road, Moratuwa', 'cleaner');
INSERT INTO Employee VALUES('e007', 'Dilan Perera', '+94 77 789 0123', '246 Kandy Road, Kadawatha', 'worker');
INSERT INTO Employee VALUES('e008', 'Sahan Silva', '+94 76 890 1234', '369 Negombo Road, Ja-ela', 'worker');
INSERT INTO Employee VALUES('e009', 'Chamara Rajapakse', '+94 71 901 2345', '987 Colombo Road, Nugegoda', 'receptionist');
INSERT INTO Employee VALUES('e010', 'Nimal Perera', '+94 77 012 3456', '654 Galle Road, Mount Lavinia', 'worker');



INSERT INTO User VALUES('niko','1');
INSERT INTO User VALUES('dathusena','letmein');
INSERT INTO User VALUES('1','1');


INSERT INTO Salary VALUES('s001','john doily',50000,'4/3/2023', 'e001');
INSERT INTO Salary VALUES('s002','jane doe',60000,'4/3/2023', 'e002');
INSERT INTO Salary VALUES('s003','jack smith',55000,'4/3/2023', 'e003');
INSERT INTO Salary VALUES('s004','mary lee',75000,'4/3/2023', 'e004');
INSERT INTO Salary VALUES('s005','adam turner',40000,'4/3/2023', 'e005');
INSERT INTO Salary VALUES('s006','sarah jones',80000,'4/3/2023', 'e006');
INSERT INTO Salary VALUES('s007','david morgan',45000,'4/3/2023', 'e007');
INSERT INTO Salary VALUES('s008','kelly smith',55000,'4/3/2023', 'e008');
INSERT INTO Salary VALUES('s009','joshua taylor',70000,'4/3/2023', 'e009');
INSERT INTO Salary VALUES('s010','emily anderson',65000,'4/3/2023', 'e010');


INSERT INTO Stock VALUES('st001','Towels', 100);
INSERT INTO Stock VALUES('st002','Bed Linens', 150);
INSERT INTO Stock VALUES('st003','Pillows', 75);
INSERT INTO Stock VALUES('st004','Toiletries', 200);
INSERT INTO Stock VALUES('st005','Cleaning Supplies', 50);
INSERT INTO Stock VALUES('st006','Utensils', 50);
INSERT INTO Stock VALUES('st007','Cups', 75);
INSERT INTO Stock VALUES('st008','Plates', 75);
INSERT INTO Stock VALUES('st009','Coffee Machine', 10);
INSERT INTO Stock VALUES('st010','Iron', 25);


INSERT INTO Guest VALUES('g001', 'John Doe', '1st street','new york','8056','usa','new york',34/*,'2023-04-07','2023-04-07',2, 'R001'*/);
INSERT INTO Guest VALUES('g002', 'Jane Smith', '2nd street', 'Los Angeles', '90210', 'USA', 'California', 28/*, '2023-04-07', '2023-04-07', 1, 'R002'*/);
INSERT INTO Guest VALUES('g003', 'Mark Johnson', '3rd avenue', 'Chicago', '60601', 'USA', 'Illinois', 42 /*,'2023-04-07', '2023-04-07', 1, 'R003'*/);
INSERT INTO Guest VALUES('g004', 'Samantha Lee', '4th street', 'San Francisco', '94103', 'USA', 'California', 25 /*,'2023-04-07', '2023-04-07', 1, 'R004'*/);
INSERT INTO Guest VALUES('g005', 'David Brown', '5th avenue', 'Boston', '02108', 'USA', 'Massachusetts', 31/*, '2023-04-07', '2023-04-07', 1, 'R005'*/);
INSERT INTO Guest VALUES('g006', 'Sarah Wilson', '6th street', 'Seattle', '98101', 'USA', 'Washington', 29);
INSERT INTO Guest VALUES('g007', 'Michael Davis', '7th street', 'Austin', '78701', 'USA', 'Texas', 37);
INSERT INTO Guest VALUES('g008', 'Emily Taylor', '8th avenue', 'Philadelphia', '19102', 'USA', 'Pennsylvania', 24);
INSERT INTO Guest VALUES('g009', 'Christopher Wilson', '9th street', 'Miami', '33131', 'USA', 'Florida', 27);
INSERT INTO Guest VALUES('g010', 'Jessica Anderson', '10th street', 'Denver', '80202', 'USA', 'Colorado', 33);
INSERT INTO Guest VALUES('g011', 'Thomas Miller', '11th street', 'Dallas', '75201', 'USA', 'Texas', 39);
INSERT INTO Guest VALUES('g012', 'Hannah Garcia', '12th street', 'Phoenix', '85001', 'USA', 'Arizona', 29);
INSERT INTO Guest VALUES('g013', 'David Rodriguez', '13th street', 'Houston', '77001', 'USA', 'Texas', 36);
INSERT INTO Guest VALUES('g014', 'Avery Scott', '14th street', 'Seattle', '98101', 'USA', 'Washington', 27);
INSERT INTO Guest VALUES('g015', 'Isabella Adams', '15th street', 'Austin', '78701', 'USA', 'Texas', 23);
INSERT INTO Guest VALUES('g016', 'Josephine Kim', '16th street', 'Philadelphia', '19102', 'USA', 'Pennsylvania', 25);
INSERT INTO Guest VALUES('g017', 'Sophie Smith', '17th avenue', 'New York', '10001', 'USA', 'New York', 28);
INSERT INTO Guest VALUES('g018', 'Isabella Thompson', '18th street', 'Los Angeles', '90015', 'USA', 'California', 25);
INSERT INTO Guest VALUES('g019', 'Ryan Clark', '19th street', 'Chicago', '60603', 'USA', 'Illinois', 32);
INSERT INTO Guest VALUES('g020', 'Olivia Wright', '20th street', 'San Francisco', '94103', 'USA', 'California', 29);
INSERT INTO Guest VALUES('g021', 'William Turner', '21st street', 'Boston', '02108', 'USA', 'Massachusetts', 36);
INSERT INTO Guest VALUES('g022', 'Jacob Patel', '22nd street', 'San Francisco', '94102', 'USA', 'California', 29);
INSERT INTO Guest VALUES('g023', 'Samantha Lee', '23rd street', 'Boston', '02108', 'USA', 'Massachusetts', 35);
INSERT INTO Guest VALUES('g024', 'Avery Robinson', '24th street', 'Seattle', '98101', 'USA', 'Washington', 26);
INSERT INTO Guest VALUES('g025', 'Alexander Wright', '25th street', 'Chicago', '60601', 'USA', 'Illinois', 31);
INSERT INTO Guest VALUES('g026', 'Mia Hernandez', '26th street', 'Miami', '33131', 'USA', 'Florida', 28);
INSERT INTO Guest VALUES('g027', 'Nathan Johnson', '27th avenue', 'Los Angeles', '90014', 'USA', 'California', 31);
INSERT INTO Guest VALUES('g028', 'Olivia White', '28th street', 'Chicago', '60601', 'USA', 'Illinois', 26);
INSERT INTO Guest VALUES('g029', 'William Martinez', '29th street', 'Houston', '77002', 'USA', 'Texas', 35);
INSERT INTO Guest VALUES('g030', 'Avery Lee', '30th street', 'Atlanta', '30303', 'USA', 'Georgia', 30);
INSERT INTO Guest VALUES('g031', 'Hannah Moore', '31st avenue', 'Seattle', '98101', 'USA', 'Washington', 23);
INSERT INTO Guest VALUES('g032', 'Aiden Clark', '32nd street', 'San Francisco', '94105', 'USA', 'California', 25);
INSERT INTO Guest VALUES('g033', 'Ella Baker', '33rd avenue', 'New York', '10001', 'USA', 'New York', 29);
INSERT INTO Guest VALUES('g034', 'Noah Green', '34th street', 'Austin', '78701', 'USA', 'Texas', 32);
INSERT INTO Guest VALUES('g035', 'Avery Hill', '35th avenue', 'Denver', '80202', 'USA', 'Colorado', 28);
INSERT INTO Guest VALUES('g036', 'Oliver Cooper', '36th street', 'Chicago', '60601', 'USA', 'Illinois', 30);
INSERT INTO Guest VALUES('g037', 'Sophia Adams', '37th avenue', 'Los Angeles', '90071', 'USA', 'California', 26);
INSERT INTO Guest VALUES('g038', 'William Lee', '38th street', 'Philadelphia', '19102', 'USA', 'Pennsylvania', 33);
INSERT INTO Guest VALUES('g039', 'Chloe Foster', '39th avenue', 'Dallas', '75201', 'USA', 'Texas', 31);
INSERT INTO Guest VALUES('g040', 'Henry Campbell', '40th street', 'Boston', '02108', 'USA', 'Massachusetts', 27);
INSERT INTO Guest VALUES('g041', 'Isabella James', '41st avenue', 'Miami', '33131', 'USA', 'Florida', 29);
INSERT INTO Guest VALUES('g042', 'Jacob Perez', '42nd street', 'San Francisco', '94102', 'USA', 'California', 34);
INSERT INTO Guest VALUES('g043', 'Olivia Brown', '43rd street', 'New York', '10001', 'USA', 'New York', 26);
INSERT INTO Guest VALUES('g044', 'William Lee', '44th street', 'Seattle', '98101', 'USA', 'Washington', 31);
INSERT INTO Guest VALUES('g045', 'Sophia Green', '45th avenue', 'Los Angeles', '90001', 'USA', 'California', 28);
INSERT INTO Guest VALUES('g046', 'Daniel Martin', '46th avenue', 'Chicago', '60601', 'USA', 'Illinois', 35);
INSERT INTO Guest VALUES('g047', 'Olivia Smith', '47th street', 'San Francisco', '94102', 'USA', 'California', 31);
INSERT INTO Guest VALUES('g048', 'Liam Johnson', '48th street', 'New York', '10001', 'USA', 'New York', 26);
INSERT INTO Guest VALUES('g049', 'Avery Rodriguez', '49th avenue', 'Los Angeles', '90001', 'USA', 'California', 22);
INSERT INTO Guest VALUES('g050', 'Benjamin Perez', '50th street', 'Houston', '77002', 'USA', 'Texas', 28);
INSERT INTO Guest VALUES('g051', 'Sophia Garcia', '51st street', 'Miami', '33131', 'USA', 'Florida', 24);
INSERT INTO Guest VALUES('g052', 'Lucas Hernandez', '52nd street', 'Seattle', '98101', 'USA', 'Washington', 27);
INSERT INTO Guest VALUES('g053', 'Aria Martin', '53rd avenue', 'Chicago', '60601', 'USA', 'Illinois', 33);
INSERT INTO Guest VALUES('g054', 'Ethan Thompson', '54th avenue', 'Dallas', '75201', 'USA', 'Texas', 29);
INSERT INTO Guest VALUES('g055', 'Avery Lewis', '55th street', 'New York', '10001', 'USA', 'New York', 26);
INSERT INTO Guest VALUES('g056', 'Harper Hall', '56th street', 'Los Angeles', '90001', 'USA', 'California', 22);
INSERT INTO Guest VALUES('g057', 'Olivia Brown', '57th street', 'San Francisco', '94101', 'USA', 'California', 26);
INSERT INTO Guest VALUES('g058', 'Ethan Garcia', '58th street', 'San Diego', '92101', 'USA', 'California', 32);
INSERT INTO Guest VALUES('g059', 'Avery Perez', '59th street', 'Houston', '77001', 'USA', 'Texas', 27);
INSERT INTO Guest VALUES('g060', 'Lucas Flores', '60th street', 'Philadelphia', '19102', 'USA', 'Pennsylvania', 23);
INSERT INTO Guest VALUES('g061', 'Natalie Martin', '61st avenue', 'Atlanta', '30301', 'USA', 'Georgia', 34);
INSERT INTO Guest VALUES('g062', 'Landon Wright', '62nd street', 'Denver', '80202', 'USA', 'Colorado', 31);







INSERT INTO Booking VALUES('bk001', '2023-04-01', '2023-04-01' , 2 , 'R001' , 'g001');
INSERT INTO Booking VALUES('bk002', '2023-04-02', '2023-04-02', 1, 'R002', 'g002');
INSERT INTO Booking VALUES('bk003', '2023-04-03', '2023-04-03', 3, 'R003', 'g003');
INSERT INTO Booking VALUES('bk004', '2023-04-04', '2023-04-06', 2, 'R004', 'g004');
INSERT INTO Booking VALUES('bk005', '2023-04-05', '2023-04-08', 4, 'R005', 'g005');
INSERT INTO Booking VALUES('bk006', '2023-04-06', '2023-04-10', 1, 'R006', 'g006');
INSERT INTO Booking VALUES('bk007', '2023-04-07', '2023-04-09', 2, 'R007', 'g007');
INSERT INTO Booking VALUES('bk008', '2023-04-08', '2023-04-12', 3, 'R008', 'g008');
INSERT INTO Booking VALUES('bk009', '2023-04-09', '2023-04-11', 2, 'R009', 'g009');
INSERT INTO Booking VALUES('bk010', '2023-04-10', '2023-04-13', 1, 'R010', 'g010');
INSERT INTO Booking VALUES('bk011', '2023-04-11', '2023-04-14', 2, 'R011', 'g011');

INSERT INTO Booking VALUES('bk012', '2023-04-12', '2023-04-15', 3, 'R012', 'g012');
INSERT INTO Booking VALUES('bk013', '2023-04-13', '2023-04-16', 2, 'R013', 'g013');
INSERT INTO Booking VALUES('bk014', '2023-04-14', '2023-04-17', 1, 'R014', 'g014');
INSERT INTO Booking VALUES('bk015', '2023-04-15', '2023-04-18', 4, 'R015', 'g015');
INSERT INTO Booking VALUES('bk016', '2023-04-16', '2023-04-20', 2, 'R016', 'g016');
INSERT INTO Booking VALUES('bk017', '2023-04-17', '2023-04-21', 1, 'R017', 'g017');
INSERT INTO Booking VALUES('bk018', '2023-04-18', '2023-04-19', 2, 'R018', 'g018');
INSERT INTO Booking VALUES('bk019', '2023-04-19', '2023-04-22', 3, 'R019', 'g019');
INSERT INTO Booking VALUES('bk020', '2023-04-20', '2023-04-23', 1, 'R020', 'g020');
INSERT INTO Booking VALUES('bk021', '2023-04-21', '2023-04-24', 2, 'R021', 'g021');
INSERT INTO Booking VALUES('bk022', '2023-04-22', '2023-04-25', 3, 'R022', 'g022');
INSERT INTO Booking VALUES('bk023', '2023-04-23', '2023-04-26', 4, 'R023', 'g023');
INSERT INTO Booking VALUES('bk024', '2023-04-24', '2023-04-27', 1, 'R024', 'g024');
INSERT INTO Booking VALUES('bk025', '2023-04-25', '2023-04-29', 2, 'R025', 'g025');
INSERT INTO Booking VALUES('bk026', '2023-04-26', '2023-04-30', 3, 'R026', 'g026');
INSERT INTO Booking VALUES('bk027', '2023-04-27', '2023-05-01', 2, 'R027', 'g027');
INSERT INTO Booking VALUES('bk028', '2023-04-28', '2023-05-02', 1, 'R028', 'g028');
INSERT INTO Booking VALUES('bk029', '2023-04-29', '2023-05-03', 2, 'R029', 'g029');
INSERT INTO Booking VALUES('bk030', '2023-04-30', '2023-05-04', 3, 'R030', 'g030');
INSERT INTO Booking VALUES('bk031', '2023-05-01', '2023-05-05', 4, 'R031', 'g031');
INSERT INTO Booking VALUES('bk032', '2023-05-02', '2023-05-06', 2, 'R032', 'g032');

INSERT INTO Booking VALUES('bk033', '2023-05-03', '2023-05-05', 1, 'R033', 'g033');
INSERT INTO Booking VALUES('bk034', '2023-05-04', '2023-05-07', 2, 'R034', 'g034');
INSERT INTO Booking VALUES('bk035', '2023-05-05', '2023-05-09', 3, 'R035', 'g035');
INSERT INTO Booking VALUES('bk036', '2023-05-06', '2023-05-08', 2, 'R036', 'g036');
INSERT INTO Booking VALUES('bk037', '2023-05-07', '2023-05-09', 1, 'R037', 'g037');
INSERT INTO Booking VALUES('bk038', '2023-05-08', '2023-05-11', 3, 'R038', 'g038');
INSERT INTO Booking VALUES('bk039', '2023-05-09', '2023-05-13', 2, 'R039', 'g039');
INSERT INTO Booking VALUES('bk040', '2023-05-10', '2023-05-12', 1, 'R040', 'g040');
INSERT INTO Booking VALUES('bk041', '2023-05-11', '2023-05-14', 4, 'R041', 'g041');
INSERT INTO Booking VALUES('bk042', '2023-05-12', '2023-05-15', 3, 'R042', 'g042');
INSERT INTO Booking VALUES('bk043', '2023-05-13', '2023-05-16', 2, 'R043', 'g043');
INSERT INTO Booking VALUES('bk044', '2023-05-14', '2023-05-16', 1, 'R044', 'g044');
INSERT INTO Booking VALUES('bk045', '2023-05-15', '2023-05-18', 3, 'R045', 'g045');
INSERT INTO Booking VALUES('bk046', '2023-05-16', '2023-05-19', 2, 'R046', 'g046');
INSERT INTO Booking VALUES('bk047', '2023-05-17', '2023-05-20', 1, 'R047', 'g047');
INSERT INTO Booking VALUES('bk048', '2023-05-18', '2023-05-20', 2, 'R048', 'g048');
INSERT INTO Booking VALUES('bk049', '2023-05-19', '2023-05-22', 3, 'R049', 'g049');
INSERT INTO Booking VALUES('bk050', '2023-05-20', '2023-05-24', 4, 'R050', 'g050');
INSERT INTO Booking VALUES('bk051', '2023-05-21', '2023-05-23', 2, 'R051', 'g051');
INSERT INTO Booking VALUES('bk052', '2023-05-22', '2023-05-24', 1, 'R052', 'g052');
INSERT INTO Booking VALUES('bk053', '2023-05-23', '2023-05-25', 2, 'R053', 'g053');
INSERT INTO Booking VALUES('bk054', '2023-05-24', '2023-05-27', 3, 'R054', 'g054');
INSERT INTO Booking VALUES('bk055', '2023-05-25', '2023-05-29', 4, 'R055', 'g055');
INSERT INTO Booking VALUES('bk056', '2023-05-26', '2023-05-28', 2, 'R056', 'g056');
INSERT INTO Booking VALUES('bk057', '2023-05-27', '2023-05-31', 3, 'R057', 'g057');
INSERT INTO Booking VALUES('bk058', '2023-05-28', '2023-06-01', 4, 'R058', 'g058');
INSERT INTO Booking VALUES('bk059', '2023-05-29', '2023-06-02', 2, 'R059', 'g059');
INSERT INTO Booking VALUES('bk060', '2023-05-30', '2023-06-03', 3, 'R060', 'g060');
INSERT INTO Booking VALUES('bk061', '2023-05-31', '2023-06-04', 1, 'R061', 'g061');
INSERT INTO Booking VALUES('bk062', '2023-06-01', '2023-06-05', 2, 'R062', 'g062');





INSERT INTO Room VALUES('r001','Standard',3,6,40000.00);
INSERT INTO Room VALUES('r002','Standard',2,6,40000.00);
INSERT INTO Room VALUES('r003' ,'Deluxe',4,4,60000.00);
INSERT INTO Room VALUES('r004' ,'Standard',5,6,40000.00);
INSERT INTO Room VALUES('r005' ,'Superior',4,3,80000.00);
INSERT INTO Room VALUES('r006','Standard',3,6,40000.00);
INSERT INTO Room VALUES('r007','Deluxe',2,4,60000.00);
INSERT INTO Room VALUES('r008','Superior',1,3,80000.00);
INSERT INTO Room VALUES('r009' ,'Standard',2,6,40000.00);
INSERT INTO Room VALUES('r010' ,'Deluxe',3,4,60000.00);

INSERT INTO RoomStatus VALUES('r001','Standard',3,6,40000.00,'available','g001');
INSERT INTO RoomStatus VALUES('r002','Standard',2,6,40000.00,'occupied','g002');
INSERT INTO RoomStatus VALUES('r003','Deluxe',3,6,40000.00,'available','g003');
INSERT INTO RoomStatus VALUES('r004','Standard',2,6,40000.00,'occupied','g004');
INSERT INTO RoomStatus VALUES('r005','Superior',3,6,40000.00,'available','g005');
INSERT INTO RoomStatus VALUES('r006','Standard',2,6,40000.00,'occupied','g006');
INSERT INTO RoomStatus VALUES('r007','Deluxe',3,6,40000.00,'available','g007');
INSERT INTO RoomStatus VALUES('r008','Superior',2,6,40000.00,'occupied','g008');
INSERT INTO RoomStatus VALUES('r009','Standard',3,6,40000.00,'available','g009');
INSERT INTO RoomStatus VALUES('r010','Deluxe',2,6,40000.00,'occupied','g010');

INSERT INTO Reservation VALUES('rsv001', 'Standard', 'r001');
INSERT INTO Reservation VALUES('rsv002', 'Deluxe', 'r002');
INSERT INTO Reservation VALUES('rsv003', 'Suite', 'r003');
INSERT INTO Reservation VALUES('rsv004', 'Standard', 'r004');
INSERT INTO Reservation VALUES('rsv005', 'Deluxe', 'r005');
INSERT INTO Reservation VALUES('rsv006', 'Suite', 'r006');
INSERT INTO Reservation VALUES('rsv007', 'Standard', 'r007');
INSERT INTO Reservation VALUES('rsv008', 'Deluxe', 'r008');
INSERT INTO Reservation VALUES('rsv009', 'Suite', 'r009');
INSERT INTO Reservation VALUES('rsv010', 'Standard', 'r010');


/*INSERT INTO Booking_Room VALUES('r001', 'bk001');
INSERT INTO Booking_Room VALUES('r002', 'bk002');
INSERT INTO Booking_Room VALUES('r003', 'bk003');
INSERT INTO Booking_Room VALUES('r004', 'bk004');
INSERT INTO Booking_Room VALUES('r005', 'bk005');
INSERT INTO Booking_Room VALUES('r006', 'bk006');
INSERT INTO Booking_Room VALUES('r007', 'bk007');
INSERT INTO Booking_Room VALUES('r008', 'bk008');
INSERT INTO Booking_Room VALUES('r009', 'bk009');
INSERT INTO Booking_Room VALUES('r010', 'bk010');*/


INSERT INTO Payment VALUES('p001',  'bk001' , 'g001' , 10000.00 , '2023-03-14');
INSERT INTO Payment VALUES('p002', 'bk002', 'g002', 15000.00, '2023-03-15');
INSERT INTO Payment VALUES('p003', 'bk003', 'g003', 20000.00, '2023-03-16');
INSERT INTO Payment VALUES('p004', 'bk004', 'g004', 25000.00, '2023-03-17');
INSERT INTO Payment VALUES('p005', 'bk005', 'g005', 30000.00, '2023-03-18');
INSERT INTO Payment VALUES('p006', 'bk006', 'g006', 35000.00, '2023-03-19');
INSERT INTO Payment VALUES('p007', 'bk007', 'g007', 40000.00, '2023-03-19');
INSERT INTO Payment VALUES('p008', 'bk008', 'g008', 45000.00, '2023-03-19');
INSERT INTO Payment VALUES('p009', 'bk009', 'g009', 50000.00, '2023-03-19');
INSERT INTO Payment VALUES('p010', 'bk010', 'g010', 55000.00, '2023-03-19');
INSERT INTO Payment VALUES('p011', 'bk011', 'g011', 60000.00, '2023-03-19');
INSERT INTO Payment VALUES('p012', 'bk012', 'g012', 65000.00, '2023-03-19');
INSERT INTO Payment VALUES('p013', 'bk013', 'g013', 70000.00, '2023-03-20');
INSERT INTO Payment VALUES('p014', 'bk014', 'g014', 45000.00, '2023-03-20');
INSERT INTO Payment VALUES('p015', 'bk015', 'g015', 47000.00, '2023-03-20');
INSERT INTO Payment VALUES('p016', 'bk016', 'g016', 48000.00, '2023-03-20');
INSERT INTO Payment VALUES('p017', 'bk017', 'g017', 49000.00, '2023-03-20');
INSERT INTO Payment VALUES('p018', 'bk018', 'g018', 42000.00, '2023-03-21');
INSERT INTO Payment VALUES('p019', 'bk019', 'g019', 43000.00, '2023-03-21');
INSERT INTO Payment VALUES('p020', 'bk020', 'g020', 44000.00, '2023-03-21');
INSERT INTO Payment VALUES('p021', 'bk021', 'g021', 40000.00, '2023-03-21');
INSERT INTO Payment VALUES('p022', 'bk022', 'g022', 39000.00, '2023-03-21');
INSERT INTO Payment VALUES('p023', 'bk023', 'g023', 38000.00, '2023-03-22');
INSERT INTO Payment VALUES('p024', 'bk024', 'g024', 47000.00, '2023-03-23');
INSERT INTO Payment VALUES('p025', 'bk025', 'g025', 48000.00, '2023-03-24');
INSERT INTO Payment VALUES('p026', 'bk026', 'g026', 49000.00, '2023-03-24');
INSERT INTO Payment VALUES('p027', 'bk027', 'g027', 45000.00, '2023-03-25');
INSERT INTO Payment VALUES('p028', 'bk028', 'g028', 44000.00, '2023-03-26');
INSERT INTO Payment VALUES('p029', 'bk029', 'g029', 43000.00, '2023-03-26');
INSERT INTO Payment VALUES('p030', 'bk030', 'g030', 41000.00, '2023-03-27');
INSERT INTO Payment VALUES('p031', 'bk031', 'g031', 38000.00, '2023-03-27');
INSERT INTO Payment VALUES('p032', 'bk032', 'g032', 37000.00, '2023-03-27');
INSERT INTO Payment VALUES('p033', 'bk033', 'g033', 35000.00, '2023-03-27');
INSERT INTO Payment VALUES('p034', 'bk034', 'g034', 42000.00, '2023-03-28');
INSERT INTO Payment VALUES('p035', 'bk035', 'g035', 43000.00, '2023-03-29');
INSERT INTO Payment VALUES('p036', 'bk036', 'g036', 44000.00, '2023-04-01');
INSERT INTO Payment VALUES('p037', 'bk037', 'g037', 41000.00, '2023-04-04');
INSERT INTO Payment VALUES('p038', 'bk038', 'g038', 39000.00, '2023-04-05');
INSERT INTO Payment VALUES('p039', 'bk039', 'g039', 42000.00, '2023-04-05');
INSERT INTO Payment VALUES('p040', 'bk040', 'g040', 44000.00, '2023-04-06');
INSERT INTO Payment VALUES('p041', 'bk041', 'g041', 35000.00, '2023-04-06');
INSERT INTO Payment VALUES('p042', 'bk042', 'g042', 42000.00, '2023-04-06');
INSERT INTO Payment VALUES('p043', 'bk043', 'g043', 39000.00, '2023-04-07');
INSERT INTO Payment VALUES('p044', 'bk044', 'g044', 43000.00, '2023-04-07');
INSERT INTO Payment VALUES('p045', 'bk045', 'g045', 42000.00, '2023-04-07');
INSERT INTO Payment VALUES('p046', 'bk046', 'g046', 38000.00, '2023-04-08');
INSERT INTO Payment VALUES('p047', 'bk047', 'g047', 44000.00, '2023-04-08');
INSERT INTO Payment VALUES('p048', 'bk048', 'g048', 40000.00, '2023-04-08');
INSERT INTO Payment VALUES('p049', 'bk049', 'g049', 39000.00, '2023-04-09');
INSERT INTO Payment VALUES('p050', 'bk050', 'g050', 42000.00, '2023-04-10');
INSERT INTO Payment VALUES('p051', 'bk051', 'g051', 47000.00, '2023-04-10');
INSERT INTO Payment VALUES('p052', 'bk052', 'g052', 36000.00, '2023-04-10');
INSERT INTO Payment VALUES('p053', 'bk053', 'g053', 43000.00, '2023-04-10');
INSERT INTO Payment VALUES('p054', 'bk054', 'g054', 48000.00, '2023-04-10');
INSERT INTO Payment VALUES('p055', 'bk055', 'g055', 45000.00, '2023-04-11');
INSERT INTO Payment VALUES('p056', 'bk056', 'g056', 39000.00, '2023-04-12');
INSERT INTO Payment VALUES('p057', 'bk057', 'g057', 42000.00, '2023-04-13');
INSERT INTO Payment VALUES('p058', 'bk058', 'g058', 38000.00, '2023-04-14');
INSERT INTO Payment VALUES('p059', 'bk059', 'g059', 37000.00, '2023-04-15');
INSERT INTO Payment VALUES('p060', 'bk060', 'g060', 45000.00, '2023-04-16');
INSERT INTO Payment VALUES('p061', 'bk061', 'g061', 41000.00, '2023-04-17');
INSERT INTO Payment VALUES('p062', 'bk062', 'g062', 39000.00, '2023-04-18');/*
INSERT INTO Payment VALUES('p063', 'bk063', 'g063', 46000.00, '2023-06-15');
INSERT INTO Payment VALUES('p063', 'bk063', 'g063', 46000.00, '2023-06-15');
INSERT INTO Payment VALUES('p064', 'bk064', 'g064', 25000.00, '2023-06-16');
INSERT INTO Payment VALUES('p065', 'bk065', 'g065', 15000.00, '2023-06-17');
INSERT INTO Payment VALUES('p066', 'bk066', 'g066', 45000.00, '2023-06-18');
INSERT INTO Payment VALUES('p067', 'bk067', 'g067', 35000.00, '2023-06-19');
INSERT INTO Payment VALUES('p068', 'bk068', 'g068', 30000.00, '2023-06-20');
INSERT INTO Payment VALUES('p069', 'bk069', 'g069', 42000.00, '2023-06-21');
INSERT INTO Payment VALUES('p070', 'bk070', 'g070', 48000.00, '2023-06-22');
INSERT INTO Payment VALUES('p071', 'bk071', 'g071', 38000.00, '2023-06-23');
INSERT INTO Payment VALUES('p072', 'bk072', 'g072', 29000.00, '2023-06-24');
INSERT INTO Payment VALUES('p073', 'bk073', 'g073', 23000.00, '2023-06-25');
INSERT INTO Payment VALUES('p074', 'bk074', 'g074', 32000.00, '2023-06-26');
INSERT INTO Payment VALUES('p075', 'bk075', 'g075', 48000.00, '2023-06-27');
INSERT INTO Payment VALUES('p076', 'bk076', 'g076', 20000.00, '2023-06-28');
INSERT INTO Payment VALUES('p077', 'bk077', 'g077', 41000.00, '2023-06-29');
INSERT INTO Payment VALUES('p078', 'bk078', 'g078', 47000.00, '2023-06-30');
INSERT INTO Payment VALUES('p079', 'bk079', 'g079', 29000.00, '2023-07-01');
INSERT INTO Payment VALUES('p080', 'bk080', 'g080', 42000.00, '2023-07-02');
INSERT INTO Payment VALUES('p081', 'bk081', 'g081', 38000.00, '2023-07-03');
INSERT INTO Payment VALUES('p082', 'bk082', 'g082', 24000.00, '2023-07-04');
INSERT INTO Payment VALUES('p083', 'bk083', 'g083', 49000.00, '2023-07-05');
INSERT INTO Payment VALUES('p084', 'bk084', 'g084', 47000.00, '2023-07-06');
INSERT INTO Payment VALUES('p085', 'bk085', 'g085', 35000.00, '2023-07-07');
INSERT INTO Payment VALUES('p086', 'bk086', 'g086', 42000.00, '2023-07-08');
INSERT INTO Payment VALUES('p087', 'bk087', 'g087', 27000.00, '2023-07-09');
INSERT INTO Payment VALUES('p088', 'bk088', 'g088', 32000.00, '2023-07-10');
INSERT INTO Payment VALUES('p089', 'bk089', 'g089', 28000.00, '2023-07-11');
INSERT INTO Payment VALUES('p090', 'bk090', 'g090', 35000.00, '2023-07-12');
INSERT INTO Payment VALUES('p091', 'bk091', 'g091', 38000.00, '2023-07-13');
INSERT INTO Payment VALUES('p092', 'bk092', 'g092', 42000.00, '2023-07-14');
INSERT INTO Payment VALUES('p093', 'bk093', 'g093', 41000.00, '2023-07-15');
INSERT INTO Payment VALUES('p094', 'bk094', 'g094', 39000.00, '2023-07-16');
INSERT INTO Payment VALUES('p095', 'bk095', 'g095', 46000.00, '2023-07-17');
INSERT INTO Payment VALUES('p096', 'bk096', 'g096', 49000.00, '2023-07-18');
INSERT INTO Payment VALUES('p097', 'bk097', 'g097', 41000.00, '2023-07-19');
INSERT INTO Payment VALUES('p098', 'bk098', 'g098', 43000.00, '2023-07-20');
INSERT INTO Payment VALUES('p099', 'bk099', 'g099', 35000.00, '2023-07-21');
INSERT INTO Payment VALUES('p100', 'bk100', 'g100', 44000.00, '2023-07-22');*/












