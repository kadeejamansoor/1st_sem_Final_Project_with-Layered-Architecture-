package lk.ijse.projectseaw.controller;


import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import lk.ijse.projectseaw.model.RoomModel;

import java.sql.*;
import java.util.Properties;
import java.util.ResourceBundle;

public class AddRoom1Controller implements Initializable {
    private static final String URL = "jdbc:mysql://localhost:3306/Seew";
    private static final Properties props = new Properties();

    static {
        props.setProperty("user", "root");
        props.setProperty("password", "1234");
    }

    public TextField txtRoomid;
    public TextField txtFloorNumber;
    public TextField txtCapacity;
    public TextField txtRate;
    public ComboBox cmbRoomtype;

    @Override
    public void initialize(java.net.URL url, ResourceBundle resourceBundle) {
        ObservableList<String> RoomTypeList = FXCollections.observableArrayList();
        RoomTypeList.add("Standard");
        RoomTypeList.add("Deluxe");
        RoomTypeList.add("Superior");

        cmbRoomtype.setItems(RoomTypeList);
    }

    public void btnUpdateOnAction(ActionEvent actionEvent) {
        String Roomid = txtRoomid.getText();
        String Roomtype = cmbRoomtype.getValue().toString();
        int FloorNumber = Integer.parseInt(txtFloorNumber.getText());
        int Capacity = Integer.parseInt(txtCapacity.getText());
        double Rate = Double.parseDouble(txtRate.getText());

        try (Connection con = DriverManager.getConnection(URL, props)) {
            String sql = "UPDATE Room SET room_type = ?, floor_Number = ?, capacity = ?,  rate = ? WHERE room_id = ?";
            PreparedStatement pstm = con.prepareStatement(sql);
            pstm.setString(1, Roomtype);
            pstm.setInt(2, FloorNumber);
            pstm.setInt(3, Capacity);
            pstm.setDouble(4, Rate);
            pstm.setString(5, Roomid);

            boolean isUpdated = pstm.executeUpdate() > 0;
            if (isUpdated) {
                new Alert(Alert.AlertType.CONFIRMATION, "yes! updated!!").show();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void btnDeleteOnAction(ActionEvent actionEvent) throws SQLException {
        String id = txtRoomid.getText();
        try (Connection con = DriverManager.getConnection(URL, props)) {
            String sql = "DELETE FROM Room WHERE room_id = ?";

            PreparedStatement pstm = con.prepareStatement(sql);
            pstm.setString(1, id);

            if (pstm.executeUpdate() > 0) {
                new Alert(Alert.AlertType.CONFIRMATION, "deletd!").show();
            }
        }
    }

    public void btnClearOnAction(ActionEvent actionEvent) {

    }

    @FXML
    public void btnSaveOnAction(ActionEvent actionEvent) throws SQLException {
        String Roomid = txtRoomid.getText();
        String Roomtype = cmbRoomtype.getValue().toString();
        int FloorNumber = Integer.parseInt(txtFloorNumber.getText());
        int Capacity = Integer.parseInt(txtCapacity.getText());
        double Rate = Double.parseDouble(txtRate.getText());


////////////////

        if (roomFieldCheck(Roomid, Roomtype, FloorNumber, Capacity, Rate)) {
            if (validateRoomIdFormat(Roomid)) {
                if (RoomModel.validateRoomId(Roomid)) {
                    if (floorNumberValidate(FloorNumber)) {
                        if (capacityValidate(Capacity)) {
                            if (rateValidate(Rate)) {

                                try (Connection con = DriverManager.getConnection(URL, props)) {
                                    String sql = "INSERT INTO Room(room_id, room_type, floor_Number, capacity, rate)" +
                                            "VALUES(?, ?, ?, ?,?)";
                                    PreparedStatement pstm = con.prepareStatement(sql);
                                    pstm.setString(1, Roomid);
                                    pstm.setString(2, Roomtype);
                                    pstm.setInt(3, FloorNumber);
                                    pstm.setInt(4, Capacity);
                                    pstm.setDouble(5, Rate);

                                    int affectedRows = pstm.executeUpdate();
                                    if (affectedRows > 0) {
                                        new Alert(Alert.AlertType.CONFIRMATION,
                                                " room added successfully")
                                                .show();
                                    }
                                } catch (Exception e) {
                                    System.out.println(e.getMessage());
                                }

                            } else {
                                new Alert(Alert.AlertType.WARNING, "Invalid rate. Please enter a valid number!").show();
                            }
                        } else {
                            new Alert(Alert.AlertType.WARNING, "Invalid capacity. Please enter a valid number!").show();
                        }
                    } else {
                        new Alert(Alert.AlertType.WARNING, "Invalid floor number. Please enter valid number!").show();
                    }
                } else {
                    new Alert(Alert.AlertType.WARNING, "The room ID already exists, please use a different ID.").show();
                }
            } else {
                new Alert(Alert.AlertType.WARNING, "Invalid guest id. Please enter valid id!").show();
            }
        } else {
            new Alert(Alert.AlertType.WARNING, "Please fill all the fields!").show();
        }
    }

    public boolean rateValidate(double rate) {
        if (!Double.toString(rate).matches("^\\d+(\\.\\d+)?$")) {
            return false;
        }
        return true;
    }

    public boolean capacityValidate(int capacity) {
        int capacityNum = capacity;
        if (capacityNum <= 0) {
            return false;
        }
        return true;
    }

    public boolean floorNumberValidate(int FloorNumber) {
        if (FloorNumber <= 0) {
            return false;
        }
        return true;
    }

    private boolean validateRoomIdFormat(String Roomid) {
        String regex = "^r\\d{3}$";  // r001, r011, r123, r456
        return Roomid.matches(regex);
    }

    public boolean roomFieldCheck(String roomId, String roomType, Integer floorNumber, Integer capacity, Double rate) {
        if (roomId.isEmpty() || roomType.isEmpty() || floorNumber == null || capacity == null || rate == null) {
            return false;
        }
        // add other validations for room fields here
        return true;
    }


    @FXML
    void btnCodeSearchOnAction(ActionEvent event) throws SQLException {
        String Roomid = txtRoomid.getText();


        try (Connection con = DriverManager.getConnection(URL, props)) {
            String sql = "SELECT * FROM Room WHERE room_id = ?";
            PreparedStatement pstm = con.prepareStatement(sql);
            pstm.setString(1, Roomid);

            ResultSet resultSet = pstm.executeQuery();
            if (resultSet.next()) {
                String room_id = resultSet.getString(1);
                String room_type = resultSet.getString(2);
                int floor_Number = resultSet.getInt(3);
                int capacity = resultSet.getInt(4);
                double rate = resultSet.getDouble(5);


                txtRoomid.setText(room_id);
                cmbRoomtype.setValue(room_type);
                txtFloorNumber.setText(String.valueOf(floor_Number));
                txtCapacity.setText(String.valueOf(capacity));
                txtRate.setText(String.valueOf(rate));
            }
        }
    }


}
