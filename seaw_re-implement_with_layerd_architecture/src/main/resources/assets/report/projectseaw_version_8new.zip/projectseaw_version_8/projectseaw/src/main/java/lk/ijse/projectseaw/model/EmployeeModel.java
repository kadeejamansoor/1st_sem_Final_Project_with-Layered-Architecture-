package lk.ijse.projectseaw.model;

import lk.ijse.projectseaw.dto.EmployeeDTO;
import lk.ijse.projectseaw.util.CrudUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.Properties;

public class EmployeeModel {
    private static final String URL = "jdbc:mysql://localhost:3306/seew";
    private static final Properties props = new Properties();

    static {
        props.setProperty("user", "root");
        props.setProperty("password", "1234");
    }



    public boolean save(EmployeeDTO dto) throws SQLException, ClassNotFoundException {
        return CrudUtil.crudUtil("insert into employee values(?,?,?,?,?)",
                dto.getId(),
                dto.getName(),
                dto.getContact(),
                dto.getAddress(),
                dto.getRole()
        );
    }

    public static boolean update(EmployeeDTO dto) throws SQLException, ClassNotFoundException {
        return CrudUtil.crudUtil("update employee set name=?,contact=?,address=?,role=? where id=?",
                dto.getName(),
                dto.getContact(),
                dto.getAddress(),
                dto.getRole(),
                dto.getId()
        );
    }

    public static boolean delete(String id) throws SQLException, ClassNotFoundException {
        return CrudUtil.crudUtil("delete from employee where id=?", id);
    }

    public static EmployeeDTO search(String id) throws SQLException, ClassNotFoundException {
        ResultSet rst = CrudUtil.crudUtil("SELECT*from employee where id=?", id);
        if (rst.next()) {
            return new EmployeeDTO(
                    rst.getString(1),
                    rst.getString(2),
                    rst.getString(3),
                    rst.getString(4),
                    rst.getString(5)
            );
        }
        return null;
    }

    public ArrayList<EmployeeDTO> getAll() throws SQLException, ClassNotFoundException {
        ArrayList<EmployeeDTO> all = new ArrayList<>();
        ResultSet sst = CrudUtil.crudUtil("SELECT * from employee");
        while (sst.next()) {
            all.add(
                    new EmployeeDTO(
                            sst.getString(1),
                            sst.getString(2),
                            sst.getString(3),
                            sst.getString(4),
                            sst.getString(5)

                    )
            );
        }
        return all;
    }

    public static boolean validateEmployeeId(String empid) {
        try (Connection con = DriverManager.getConnection(URL, props)) {
            String query = "SELECT * FROM Employee WHERE empid = ?";
            PreparedStatement pstm = con.prepareStatement(query);
            pstm.setString(1, empid);
            ResultSet rs = pstm.executeQuery();
            return !rs.next();
        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }
    }


}
