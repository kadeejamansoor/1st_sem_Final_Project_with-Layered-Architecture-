package lk.ijse.projectseaw.dto;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString

public class RoomReservation {
    private String reservationId;
    private String roomType;
    private String roomId;
}
