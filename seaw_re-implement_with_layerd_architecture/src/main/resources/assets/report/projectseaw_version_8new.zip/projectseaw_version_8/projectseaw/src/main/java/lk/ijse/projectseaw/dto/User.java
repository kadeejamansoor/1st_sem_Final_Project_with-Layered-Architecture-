package lk.ijse.projectseaw.dto;


import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString

public class User {
    private String Username;
    private String Password;
}

