package lk.ijse.projectseaw.model;

import lk.ijse.projectseaw.db.DBConnection;
import lk.ijse.projectseaw.dto.RoomStatus;
import lk.ijse.projectseaw.dto.tm.Room;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

public class RoomModel {
    private static final String URL = "jdbc:mysql://localhost:3306/seew";
    private static final Properties props = new Properties();

    static {
        props.setProperty("user", "root");
        props.setProperty("password", "1234");
    }


    public static List<Room> getAll() throws SQLException, ClassNotFoundException {

        /*ResultSet set= CrudUtil.crudUtil("SELECT * from room");
        ArrayList<RoomTm>list=new ArrayList<>();
        RoomTm tm=null;
        while (set.next()){
            tm=new RoomTm();
            tm.setRoomId(set.getString(1));
            tm.setRoom_type(set.getString(2));
            tm.setGuestId(set.getString(3));
            tm.setFloor(set.getString(4));
            tm.setCapacity(set.getString(5));
            tm.setRate(set.getString(6));

            list.add(tm);
        }
        System.gc();
        return list;*/

        Connection con = DBConnection.getInstance().getConnection();
        String sql = "SELECT * FROM Room";

        List<Room> data = new ArrayList<>();

        ResultSet resultSet = con.createStatement().executeQuery(sql);
        while (resultSet.next()) {
            data.add(new Room(
                    resultSet.getString(1),
                    resultSet.getString(2),
                    resultSet.getInt(3),
                    resultSet.getInt(4),
                    resultSet.getDouble(5)
            ));
        }
        return data;
    }

    public static List<String> loadIds() throws SQLException, ClassNotFoundException {
        Connection con = DBConnection.getInstance().getConnection();
        ResultSet resultSet = con.createStatement().executeQuery("SELECT id FROM Room");

        List<String> data = new ArrayList<>();

        while (resultSet.next()) {
            data.add(resultSet.getString(1));
        }
        return data;
    }

    public static Room searchById(String id) throws SQLException, ClassNotFoundException {
        Connection con = DBConnection.getInstance().getConnection();

        PreparedStatement pstm = con.prepareStatement("SELECT * FROM Room WHERE id = ?");
        pstm.setString(1, id);

        ResultSet resultSet = pstm.executeQuery();
        if(resultSet.next()) {
            return  new Room(
                    resultSet.getString(1),
                    resultSet.getString(2),
                    resultSet.getInt(3),
                    resultSet.getInt(4),
                    resultSet.getDouble(5)
            );
        }
        return null;
    }

    public static boolean validateRoomId(String roomid) {
        try (Connection con = DriverManager.getConnection(URL, props)) {
            String query = "SELECT room_id FROM Room WHERE room_id = ?";
            PreparedStatement pstm = con.prepareStatement(query);
            pstm.setString(1, roomid);
            ResultSet rs = pstm.executeQuery();
            return !rs.next();
        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }
    }

}
