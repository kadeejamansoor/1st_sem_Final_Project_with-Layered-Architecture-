package lk.ijse.projectseaw.model;

import lk.ijse.projectseaw.db.DBConnection;
import lk.ijse.projectseaw.dto.Stock;
import lk.ijse.projectseaw.dto.User;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

public class UserModel {
    private static final String URL = "jdbc:mysql://localhost:3306/seew";
    private static final Properties props = new Properties();

    static {
        props.setProperty("user", "root");
        props.setProperty("password", "1234");
    }

    public static boolean save(User user) throws SQLException {
        try (Connection con = DriverManager.getConnection(URL, props)) {
            String sql = "INSERT INTO User(username, password) " +
                    "VALUES(?, ?)";

            PreparedStatement pstm = con.prepareStatement(sql);
            pstm.setString(1, user.getUsername());
            pstm.setString(2, user.getPassword());

            return pstm.executeUpdate() > 0;
        }
    }

    public static boolean validateUsernameANDpassword(String Username) {
        try (Connection con = DriverManager.getConnection(URL, props)) {
            String query = "SELECT * FROM User WHERE username = ?";
            PreparedStatement pstm = con.prepareStatement(query);
            pstm.setString(1, Username);
            ResultSet rs = pstm.executeQuery();
            return !rs.next();
        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }
    }

    public static List<User> getAll() throws SQLException, ClassNotFoundException {
        Connection con = DBConnection.getInstance().getConnection();
        String sql = "SELECT * FROM User";

        List<User> data = new ArrayList<>();

        ResultSet resultSet = con.createStatement().executeQuery(sql);
        while (resultSet.next()) {
            data.add(new User(
                    resultSet.getString(1),
                    resultSet.getString(2)
            ));
        }
        return data;
    }

    public static boolean update(String Username, String Password) throws SQLException {
        try (Connection con = DriverManager.getConnection(URL, props)) {
            String sql = "UPDATE User SET password = ? WHERE username = ?";
            PreparedStatement pstm = con.prepareStatement(sql);
            pstm.setString(1, Password);
            pstm.setString(2, Username);

            return pstm.executeUpdate() > 0;

        }
    }

    public static boolean delete(String Username) throws SQLException {
        try (Connection con = DriverManager.getConnection(URL, props)) {
            String sql = "DELETE FROM User WHERE username = ?";
            PreparedStatement pstm = con.prepareStatement(sql);
            pstm.setString(1, Username);

            return pstm.executeUpdate() > 0;
        }
    }
}
