package lk.ijse.projectseaw.controller;

import com.jfoenix.controls.JFXButton;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import lk.ijse.projectseaw.dto.Booking;
import lk.ijse.projectseaw.model.BookingModel;

import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ResourceBundle;
//inhertance
public class BookingInformationFormController implements Initializable {
    public JFXButton dashboardbtn;
    public JFXButton bookingbtn;
    public JFXButton reservationbtn;
    public JFXButton roombtn;
    public JFXButton stockbtn;
    public JFXButton employeebtn;
    public JFXButton billingbtn;
    public JFXButton settingbtn;
    public JFXButton logoutbtn;

    public TextField txtGuestId;
    public TextField txtFullname;
    public TextField txtAddress;
    public TextField txtCity;
    public TextField txtPostalcode;
    public TextField txtCountry;
    public TextField txtState;
    public TextField txtAge;

    public TextField txtBookingId;
    public DatePicker dtpkCheckin;
    public DatePicker dtpkCheckout;
    public ComboBox cmbSelectRoom;
    public ComboBox cmbGuest;
    public TextField txtBookingGuestId;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        ObservableList<String> noOfGuestList = FXCollections.observableArrayList();
        noOfGuestList.add("1");
        noOfGuestList.add("2");
        noOfGuestList.add("3");
        noOfGuestList.add("4");
        noOfGuestList.add("5");
        cmbGuest.setItems(noOfGuestList);

        ObservableList<String> roomList = FXCollections.observableArrayList();
        roomList.add("R001");
        roomList.add("R002");
        roomList.add("R003");
        roomList.add("R004");
        roomList.add("R005");
        roomList.add("R006");
        roomList.add("R007");
        roomList.add("R008");
        roomList.add("R009");
        roomList.add("R010");
        cmbSelectRoom.setItems(roomList);
    }


    public void btnDashboardOnAction(ActionEvent actionEvent) throws IOException {
        Parent fxmlLoader = FXMLLoader.load(getClass().getResource("/view/DashBord.fxml"));
        Stage window = (Stage) dashboardbtn.getScene().getWindow();
        window.setScene(new Scene(fxmlLoader));
        window.setTitle("Dashboard");
        window.setMaximized(true);
        window.centerOnScreen();
    }

    public void btnBookingOnAction(ActionEvent actionEvent) throws IOException {
        Parent fxmlLoader = FXMLLoader.load(getClass().getResource("/view/BookingInformationForm.fxml"));
        Stage window = (Stage) bookingbtn.getScene().getWindow();
        window.setScene(new Scene(fxmlLoader));
        window.setTitle("Booking Management");
        window.setMaximized(true);
        window.centerOnScreen();
    }

    public void btnReservationOnAction(ActionEvent actionEvent) throws IOException {
        Parent fxmlLoader = FXMLLoader.load(getClass().getResource("/view/ReservationForm.fxml"));
        Stage window = (Stage) reservationbtn.getScene().getWindow();
        window.setScene(new Scene(fxmlLoader));
        window.setTitle("Reservation");
        window.setMaximized(true);
        window.centerOnScreen();
    }

    public void btnRoomOnAction(ActionEvent actionEvent) throws IOException {
        Parent fxmlLoader = FXMLLoader.load(getClass().getResource("/view/RoomManagementForm.fxml"));
        Stage window = (Stage) roombtn.getScene().getWindow();
        window.setScene(new Scene(fxmlLoader));
        window.setTitle("Room Management");
        window.setMaximized(true);
        window.centerOnScreen();
    }

    public void btnStockOnAction(ActionEvent actionEvent) throws IOException {
        Parent fxmlLoader = FXMLLoader.load(getClass().getResource("/view/StockManagementForm.fxml"));
        Stage window = (Stage) stockbtn.getScene().getWindow();
        window.setScene(new Scene(fxmlLoader));
        window.setTitle("Stock Management");
        window.setMaximized(true);
        window.centerOnScreen();
    }

    public void btnEmployeeOnAction(ActionEvent actionEvent) throws IOException {
        Parent fxmlLoader = FXMLLoader.load(getClass().getResource("/view/EmployeeManagementForm.fxml"));
        Stage window = (Stage) employeebtn.getScene().getWindow();
        window.setScene(new Scene(fxmlLoader));
        window.setTitle("Employee Management");
        window.setMaximized(true);
        window.centerOnScreen();
    }

    public void btnBillingOnAction(ActionEvent actionEvent) throws IOException {
        Parent fxmlLoader = FXMLLoader.load(getClass().getResource("/view/BillingForm.fxml"));
        Stage window = (Stage) billingbtn.getScene().getWindow();
        window.setScene(new Scene(fxmlLoader));
        window.setTitle("Billing");
        window.setMaximized(true);
        window.centerOnScreen();
    }

    public void btnSettingOnAction(ActionEvent actionEvent) throws IOException {
        Parent fxmlLoader = FXMLLoader.load(getClass().getResource("/view/Settings1From.fxml"));
        Stage window = (Stage) settingbtn.getScene().getWindow();
        window.setScene(new Scene(fxmlLoader));
        window.setTitle("Settings");
        window.setMaximized(true);
        window.centerOnScreen();
    }

    public void btnLogoutOnAction(ActionEvent actionEvent) throws IOException {
        Stage currentStage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        AnchorPane anchorPane = FXMLLoader.load(getClass().getResource("/view/LogOut.fxml"));
        Scene scene = new Scene(anchorPane);
        Stage stage = new Stage();
        stage.setScene(scene);
        stage.setTitle("Logout page");
        stage.setMaximized(true);
        stage.centerOnScreen();
        stage.show();
        currentStage.close();
    }

    public void btnBookingManageOnAction(ActionEvent actionEvent) throws IOException {
        AnchorPane anchorPane = FXMLLoader.load(getClass().getResource("/view/BookingManagementForm.fxml"));
        Scene scene = new Scene(anchorPane);
        Stage stage = new Stage();
        stage.setScene(scene);
        stage.setTitle("Booking Management");
        stage.setMaximized(true);
        stage.centerOnScreen();
        stage.show();
    }

    public void btnSaveOnAction(ActionEvent actionEvent) {
        String guestId = txtGuestId.getText();
        String fullname = txtFullname.getText();
        String address = txtAddress.getText();
        String city = txtCity.getText();
        String postalcode = txtPostalcode.getText();
        String country = txtCountry.getText();
        String state = txtState.getText();
        int age = Integer.parseInt(txtAge.getText());

        //check guestId is already added or not
        // check if fields are empty
        if (guestFieldCheck(guestId, fullname, address, city, postalcode, country, state, String.valueOf(age))) {
            if (validateGuestIdFormat(guestId)) {
                //check guestId is already added or not
                if (BookingModel.validateGuestId(guestId)) {
                    if (validName(fullname)) {

                        try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Seew", "root", "1234")) {
                            String sql = "INSERT INTO Guest(guest_id, guest_Fullname, address, city, postal_code, country, state, age) "
                                    + "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

                            PreparedStatement pstm = con.prepareStatement(sql);
                            pstm.setString(1, guestId);
                            pstm.setString(2, fullname);
                            pstm.setString(3, address);
                            pstm.setString(4, city);
                            pstm.setString(5, postalcode);
                            pstm.setString(6, country);
                            pstm.setString(7, state);
                            pstm.setInt(8, age);



                            int affectedRows = pstm.executeUpdate();
                            if (affectedRows > 0) {
                                new Alert(Alert.AlertType.CONFIRMATION, "Guest added successfully!").show();

                            }

                            //PaymentConfirmationFormController.setGuestdetailsToLabel(guestId, fullname, address, city, postalcode, country, state, age);


                        } catch (SQLException ex) {
                            ex.printStackTrace();
                            new Alert(Alert.AlertType.ERROR, "Error occurred while adding guest!").show();
                        }

                    } else {
                        new Alert(Alert.AlertType.WARNING, "Please enter only characters. Don't use '2/@/#'. ").show();
                    }
                } else {
                    new Alert(Alert.AlertType.WARNING, "The guest ID already exists, So use different guest Id").show();
                }
            } else {
                new Alert(Alert.AlertType.WARNING, "Invalid guest id. Please enter valid id!").show();
            }

        } else {
            new Alert(Alert.AlertType.WARNING, "Please fill all the fields!").show();
        }


    }

    public boolean guestFieldCheck(String guestId, String fullname, String address, String city, String postalcode, String country, String state, String ageStr) {
        if (guestId.isEmpty() || fullname.isEmpty() || address.isEmpty() || city.isEmpty() || postalcode.isEmpty() || country.isEmpty() || state.isEmpty() || ageStr.isEmpty()) {
            //new Alert(Alert.AlertType.WARNING, "Please fill in all fields!").show();
            return false;
        } else {
            try {
                Integer.parseInt(txtAge.getText());
            } catch (NumberFormatException e) {
                new Alert(Alert.AlertType.WARNING, "Please enter a valid age!").show();
                return false;
            }
            return true;
        }
    }

    public boolean validateGuestIdFormat(String guestId) {
        String regex = "^g\\d{3}$";
        return guestId.matches(regex);
    }

    public boolean validName(String name) {
        // check if name is not null and matches the pattern "[a-zA-Z ]+"
        return name != null && name.matches("[a-zA-Z ]+");
    }

    public void btnConfirmOnAction(ActionEvent actionEvent) {
        String bookingId = txtBookingId.getText();
        LocalDate checkin = dtpkCheckin.getValue();
        LocalDate checkout = dtpkCheckout.getValue();
        System.out.println((String) cmbGuest.getValue());
        int noOfGuests = Integer.parseInt((String) cmbGuest.getValue());
        String selectedRoom = (String) cmbSelectRoom.getValue();
        String guestId = txtBookingGuestId.getText();



        if (validateBookingIdFormat(bookingId)) {
            if (BookingModel.validateBookingId(bookingId)) {

                try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Seew", "root", "1234")) {
                    String sql = "INSERT INTO Booking(booking_id, check_in, check_out, no_of_guest, select_room, guest_id) " + "VALUES (?, ?, ?, ?, ?, ?)";

                    PreparedStatement pstm = con.prepareStatement(sql);
                    pstm.setString(1, bookingId);
                    pstm.setDate(2, Date.valueOf(checkin));
                    pstm.setDate(3, Date.valueOf(checkout));
                    pstm.setInt(4, noOfGuests);
                    pstm.setString(5, selectedRoom);
                    pstm.setString(6, guestId);

                    int affectedRows = pstm.executeUpdate();
                    if (affectedRows > 0) {

                        Alert confirmationAlert = new Alert(Alert.AlertType.CONFIRMATION, "Booking added successfully!");
                        confirmationAlert.showAndWait();
                        if (confirmationAlert.getResult() == ButtonType.OK) {
                        }
                    }
                } catch (SQLException ex) {
                    ex.printStackTrace();
                    new Alert(Alert.AlertType.ERROR, "Error occurred while adding booking!").show();
                }

            }else {
                new Alert(Alert.AlertType.WARNING, "The booking ID already exists, So use different booking Id").show();
            }
        } else {
            new Alert(Alert.AlertType.WARNING, "Invalid booking id format. Please enter valid id!").show();
        }


    }

    static boolean validateBookingIdFormat(String bookingId) {
        String regex = "^bk\\d{3}$";
        return bookingId.matches(regex);
    }



    public void btnPayOnAction(ActionEvent actionEvent) throws IOException {
        AnchorPane anchorPane = FXMLLoader.load(getClass().getResource("/view/paymentConfirmationForm.fxml"));
        Scene scene = new Scene(anchorPane);
        Stage stage = new Stage();
        stage.setScene(scene);
        stage.setTitle("Payment confirmation");
        stage.setMaximized(true);
        stage.centerOnScreen();
        stage.show();
    }
}
