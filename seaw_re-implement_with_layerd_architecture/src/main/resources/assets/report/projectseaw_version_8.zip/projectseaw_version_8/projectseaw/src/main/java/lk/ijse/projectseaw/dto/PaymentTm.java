package lk.ijse.projectseaw.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@ToString
@NoArgsConstructor
@AllArgsConstructor

public class PaymentTm {
    private String colPaymentId;
    private String colBookingId;
    private String colGuestId;
    private String colAmount;
    private String colPaymentDate;
}
