package lk.ijse.projectseaw.model;

import lk.ijse.projectseaw.dto.tm.SalaryTm;
import lk.ijse.projectseaw.util.CrudUtil;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class SalaryModel {
    public static ArrayList<SalaryTm> getAllData() throws SQLException, ClassNotFoundException {
        ResultSet set= CrudUtil.crudUtil("SELECT * From salary s INNER JOIN employee e on s.emp_id = e.emp_id");
       ArrayList<SalaryTm>list=new ArrayList<>();
       SalaryTm salaryTm=new SalaryTm();
        while (set.next()){
            salaryTm.setEmpId(set.getString(1));
            salaryTm.setFullNAme(set.getString(6));
            salaryTm.setDate(set.getString(3));
            salaryTm.setAmountTm(set.getString(2));
            list.add(salaryTm);
        }
        return list;
    }
}
