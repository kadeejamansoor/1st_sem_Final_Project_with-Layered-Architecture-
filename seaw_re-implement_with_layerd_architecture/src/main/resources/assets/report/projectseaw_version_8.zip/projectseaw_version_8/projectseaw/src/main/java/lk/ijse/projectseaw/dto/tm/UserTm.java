package lk.ijse.projectseaw.dto.tm;

import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString

public class UserTm {
    private String Username;
    private String Password;
}
