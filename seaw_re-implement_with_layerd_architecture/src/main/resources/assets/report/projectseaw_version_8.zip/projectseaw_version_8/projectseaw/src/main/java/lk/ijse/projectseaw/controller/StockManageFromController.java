package lk.ijse.projectseaw.controller;


import com.jfoenix.controls.JFXButton;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import lk.ijse.projectseaw.db.DBConnection;
import lk.ijse.projectseaw.dto.Stock;
import lk.ijse.projectseaw.dto.tm.StockTm;
import lk.ijse.projectseaw.model.StockModel;
import net.sf.jasperreports.engine.*;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.view.JasperViewer;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.ResourceBundle;

public class StockManageFromController implements Initializable{

    public JFXButton dashboardbtn;
    public JFXButton bookingbtn;
    public JFXButton reservationbtn;
    public JFXButton roombtn;
    public JFXButton stockbtn;
    public JFXButton employeebtn;
    public JFXButton billingbtn;
    public JFXButton settingbtn;
    public JFXButton logoutbtn;

    public TextField txtStockId;
    public TextField txtQuantity;
    public TextField txtStockName;
    public TableView tblStockManagement;
    public TableColumn colStkId;
    public TableColumn colStkName;
    public TableColumn colQty;


    @Override
    public void initialize(java.net.URL url, ResourceBundle resourceBundle) {
        setCellValueFactory();
        getAll();
    }

    private void setCellValueFactory() {
        colStkId.setCellValueFactory(new PropertyValueFactory<>("stockId"));
        colStkName.setCellValueFactory(new PropertyValueFactory<>("StockName"));
        colQty.setCellValueFactory(new PropertyValueFactory<>("quantity"));
    }

    private void getAll() {
        try {
            ObservableList<StockTm> obList = FXCollections.observableArrayList();
            List<Stock> stockList = StockModel.getAll();

            for (Stock stock : stockList) {
                obList.add(new StockTm(
                        stock.getStockId(),
                        stock.getStockName(),
                        stock.getQuantity()
                ));
            }
            tblStockManagement.setItems(obList);
        } catch (SQLException e) {
            e.printStackTrace();
            new Alert(Alert.AlertType.ERROR, "SQL Error!").show();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    public void btnDashboardOnAction(ActionEvent actionEvent) throws IOException {
        Parent fxmlLoader =  FXMLLoader.load(getClass().getResource("/view/DashBord.fxml"));
        Stage window = (Stage)dashboardbtn.getScene().getWindow();
        window.setScene(new Scene(fxmlLoader));
        window.setTitle("Dashboard");
        window.setMaximized(true);
        window.centerOnScreen();
    }

    public void btnBookingOnAction(ActionEvent actionEvent) throws IOException {
        Parent fxmlLoader =  FXMLLoader.load(getClass().getResource("/view/BookingInformationForm.fxml"));
        Stage window = (Stage)bookingbtn.getScene().getWindow();
        window.setScene(new Scene(fxmlLoader));
        window.setTitle("Booking Management");
        window.setMaximized(true);
        window.centerOnScreen();
    }

    public void btnReservationOnAction(ActionEvent actionEvent) throws IOException {
        Parent fxmlLoader =  FXMLLoader.load(getClass().getResource("/view/ReservationForm.fxml"));
        Stage window = (Stage)reservationbtn.getScene().getWindow();
        window.setScene(new Scene(fxmlLoader));
        window.setTitle("Reservation");
        window.setMaximized(true);
        window.centerOnScreen();
    }

    public void btnRoomOnAction(ActionEvent actionEvent) throws IOException {
        Parent fxmlLoader =  FXMLLoader.load(getClass().getResource("/view/RoomManagementForm.fxml"));
        Stage window = (Stage)roombtn.getScene().getWindow();
        window.setScene(new Scene(fxmlLoader));
        window.setTitle("Room Management");
        window.setMaximized(true);
        window.centerOnScreen();
    }

    public void btnStockOnAction(ActionEvent actionEvent) throws IOException {
        Parent fxmlLoader =  FXMLLoader.load(getClass().getResource("/view/StockManagementForm.fxml"));
        Stage window = (Stage)stockbtn.getScene().getWindow();
        window.setScene(new Scene(fxmlLoader));
        window.setTitle("Stock Management");
        window.setMaximized(true);
        window.centerOnScreen();
    }

    public void btnEmployeeOnAction(ActionEvent actionEvent) throws IOException {
        Parent fxmlLoader =  FXMLLoader.load(getClass().getResource("/view/EmployeeManagementForm.fxml"));
        Stage window = (Stage)employeebtn.getScene().getWindow();
        window.setScene(new Scene(fxmlLoader));
        window.setTitle("Employee Management");
        window.setMaximized(true);
        window.centerOnScreen();
    }

    public void btnBillingOnAction(ActionEvent actionEvent) throws IOException {
        Parent fxmlLoader =  FXMLLoader.load(getClass().getResource("/view/BillingForm.fxml"));
        Stage window = (Stage)billingbtn.getScene().getWindow();
        window.setScene(new Scene(fxmlLoader));
        window.setTitle("Billing");
        window.setMaximized(true);
        window.centerOnScreen();
    }

    public void btnSettingOnAction(ActionEvent actionEvent) throws IOException {
        Parent fxmlLoader =  FXMLLoader.load(getClass().getResource("/view/Settings1From.fxml"));
        Stage window = (Stage)settingbtn.getScene().getWindow();
        window.setScene(new Scene(fxmlLoader));
        window.setTitle("Settings");
        window.setMaximized(true);
        window.centerOnScreen();
    }

    public void btnLogoutOnAction(ActionEvent actionEvent) throws IOException {
        Stage currentStage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        AnchorPane anchorPane = FXMLLoader.load(getClass().getResource("/view/LogOut.fxml"));
        Scene scene = new Scene(anchorPane);
        Stage stage = new Stage();
        stage.setScene(scene);
        stage.setTitle("Logout page");
        stage.setMaximized(true);
        stage.centerOnScreen();
        stage.show();
        currentStage.close();
    }

    public void btnUpdateOnAction(ActionEvent actionEvent) throws SQLException {
        String stockId = txtStockId.getText();
        String stockName = txtStockName.getText();
        int qty = Integer.parseInt(txtQuantity.getText());

        try {
            boolean isUpdated = StockModel.update(stockId, stockName, qty);
            new Alert(Alert.AlertType.CONFIRMATION, "Item updated!").show();
        } catch (SQLException e){

        }

    }

    public void btnDeleteOnAction(ActionEvent actionEvent) {
        String stockId = txtStockId.getText();
        try {
            boolean isDeleted = StockModel.delete(stockId);
            if (isDeleted) {
                new Alert(Alert.AlertType.CONFIRMATION, "deleted!").show();
            }
        } catch (SQLException e) {
            new Alert(Alert.AlertType.ERROR, "something went wrong!").show();
        }
    }

    public void btnClearOnAction(ActionEvent actionEvent) {
        txtStockId.clear();
        txtQuantity.clear();
        txtStockName.clear();
    }

    public void btnSaveOnAction(ActionEvent actionEvent) {
        String stockId = txtStockId.getText();
        String stockName = txtStockName.getText();
        int qty = Integer.parseInt(txtQuantity.getText());


        if (stockFieldCheck(stockId, stockName, qty)){
                if (validatestockIdFormat(stockId)){
                    if (quantityValidate(qty)){

                        Stock stock = new Stock(stockId, stockName, qty);

                        try {
                            boolean isSaved = StockModel.save(stock);
                            if (isSaved) {
                                new Alert(Alert.AlertType.CONFIRMATION, "Stock saved!").show();
                            }
                        } catch (SQLException e) {
                            e.printStackTrace();
                            new Alert(Alert.AlertType.CONFIRMATION, "The guest ID already exists, So use different guest Id").show();
                        }

                    }else {
                        new Alert(Alert.AlertType.WARNING, "Quantity must be a valid integer!").show();
                    }
                }else {
                    new Alert(Alert.AlertType.WARNING, "Invalid stock id format").show();
                }

        }else {
            new Alert(Alert.AlertType.WARNING, "Please fill all the fields with valid values!").show();
        }


    }

    public boolean stockFieldCheck(String stockId, String stockName, int qty) {
        if (stockId.isEmpty() || stockName.isEmpty() || qty <= 0) {
            return false;
        }
        // add other validations for stock fields here
        return true;
    }


    public boolean quantityValidate(int qtyText) {
        try {
            int qty = qtyText;
        } catch (NumberFormatException e) {
            return false;
        }
        return true;
    }

    private boolean validatestockIdFormat(String stockId) {
        String regex = "^st\\d{3}$";
        return stockId.matches(regex);
    }

    @FXML
    void codeSearchOnAction(ActionEvent event) {
        try {
            Stock stock = StockModel.search(txtStockId.getText());
            if (stock != null) {
                txtStockId.setText(stock.getStockId());
                txtStockName.setText(stock.getStockName());
                txtQuantity.setText(Integer.toString(stock.getQuantity()));
            }
        } catch (SQLException e) {
            new Alert(Alert.AlertType.ERROR, "something happened!").show();
        }
    }

    public void btnStockReportOnAction(ActionEvent actionEvent) {
        try {
            JasperReport jasperReport = JasperCompileManager.compileReport("E:\\projectseaw_version_8\\projectseaw\\src\\main\\resources\\assets\\report\\Stock.jrxml");
            JRDataSource jrDataSource = new JRBeanCollectionDataSource(Arrays.asList(new Object()));

            HashMap hm = new HashMap();


            Connection connection = DBConnection.getInstance().getConnection();
            JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, hm, connection);
            JasperViewer.viewReport(jasperPrint, false);
//
        } catch (JRException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }
}
