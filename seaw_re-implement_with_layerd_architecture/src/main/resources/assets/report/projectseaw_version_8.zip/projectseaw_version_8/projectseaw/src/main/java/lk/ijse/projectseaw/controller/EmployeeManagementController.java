package lk.ijse.projectseaw.controller;

import com.jfoenix.controls.JFXButton;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import lk.ijse.projectseaw.dto.EmployeeDTO;
import lk.ijse.projectseaw.model.BookingModel;
import lk.ijse.projectseaw.model.EmployeeModel;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

public class EmployeeManagementController {

    public JFXButton dashboardbtn;
    public JFXButton bookingbtn;
    public JFXButton reservationbtn;
    public JFXButton roombtn;
    public JFXButton stockbtn;
    public JFXButton employeebtn;
    public JFXButton billingbtn;
    public JFXButton settingbtn;
    public JFXButton logoutbtn;


    public TableColumn employeeManagement;
    public TableColumn name;
    public TableColumn contact;
    public TableColumn address;
    public TableColumn role;
    public TableView tbl;
    public TextField txtID;
    public TextField txtName;
    public TextField txtAddress;
    public TextField txtRole;
    public TextField txtNumber;


    public void initialize(){
        employeeManagement.setCellValueFactory(new PropertyValueFactory("id"));
        name.setCellValueFactory(new PropertyValueFactory("name"));
        contact.setCellValueFactory(new PropertyValueFactory("address"));
        address.setCellValueFactory(new PropertyValueFactory("contact"));
        role.setCellValueFactory(new PropertyValueFactory("role"));

       LoadAllCustomer();
    }

    public void btnDashboardOnAction(ActionEvent actionEvent) throws IOException {
        Parent fxmlLoader = FXMLLoader.load(getClass().getResource("/view/DashBord.fxml"));
        Stage window = (Stage) dashboardbtn.getScene().getWindow();
        window.setScene(new Scene(fxmlLoader));
        window.setTitle("Dashboard");
        window.setMaximized(true);
        window.centerOnScreen();
    }

    public void btnBookingOnAction(ActionEvent actionEvent) throws IOException {
        Parent fxmlLoader = FXMLLoader.load(getClass().getResource("/view/BookingInformationForm.fxml"));
        Stage window = (Stage) bookingbtn.getScene().getWindow();
        window.setScene(new Scene(fxmlLoader));
        window.setTitle("Booking Management");
        window.setMaximized(true);
        window.centerOnScreen();
    }

    public void btnReservationOnAction(ActionEvent actionEvent) throws IOException {
        Parent fxmlLoader = FXMLLoader.load(getClass().getResource("/view/ReservationForm.fxml"));
        Stage window = (Stage) reservationbtn.getScene().getWindow();
        window.setScene(new Scene(fxmlLoader));
        window.setTitle("Reservation");
        window.setMaximized(true);
        window.centerOnScreen();
    }

    public void btnRoomOnAction(ActionEvent actionEvent) throws IOException {
        Parent fxmlLoader = FXMLLoader.load(getClass().getResource("/view/RoomManagementForm.fxml"));
        Stage window = (Stage) roombtn.getScene().getWindow();
        window.setScene(new Scene(fxmlLoader));
        window.setTitle("Room Management");
        window.setMaximized(true);
        window.centerOnScreen();
    }

    public void btnStockOnAction(ActionEvent actionEvent) throws IOException {
        Parent fxmlLoader = FXMLLoader.load(getClass().getResource("/view/StockManagementForm.fxml"));
        Stage window = (Stage) stockbtn.getScene().getWindow();
        window.setScene(new Scene(fxmlLoader));
        window.setTitle("Stock Management");
        window.setMaximized(true);
        window.centerOnScreen();
    }

    public void btnEmployeeOnAction(ActionEvent actionEvent) throws IOException {
        Parent fxmlLoader = FXMLLoader.load(getClass().getResource("/view/EmployeeManagementForm.fxml"));
        Stage window = (Stage) employeebtn.getScene().getWindow();
        window.setScene(new Scene(fxmlLoader));
        window.setTitle("Employee Management");
        window.setMaximized(true);
        window.centerOnScreen();
    }

    public void btnBillingOnAction(ActionEvent actionEvent) throws IOException {
        Parent fxmlLoader = FXMLLoader.load(getClass().getResource("/view/BillingForm.fxml"));
        Stage window = (Stage) billingbtn.getScene().getWindow();
        window.setScene(new Scene(fxmlLoader));
        window.setTitle("Billing");
        window.setMaximized(true);
        window.centerOnScreen();
    }

    public void btnSettingOnAction(ActionEvent actionEvent) throws IOException {
        Parent fxmlLoader = FXMLLoader.load(getClass().getResource("/view/Settings1From.fxml"));
        Stage window = (Stage) settingbtn.getScene().getWindow();
        window.setScene(new Scene(fxmlLoader));
        window.setTitle("Settings");
        window.setMaximized(true);
        window.centerOnScreen();
    }

    public void btnLogoutOnAction(ActionEvent actionEvent) throws IOException {
        Stage currentStage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        AnchorPane anchorPane = FXMLLoader.load(getClass().getResource("/view/LogOut.fxml"));
        Scene scene = new Scene(anchorPane);
        Stage stage = new Stage();
        stage.setScene(scene);
        stage.setTitle("Logout page");
        stage.setMaximized(true);
        stage.centerOnScreen();
        stage.show();
        currentStage.close();
    }

    public void btnSalaryManagementOnAction(ActionEvent actionEvent) throws IOException {
        AnchorPane anchorPane = FXMLLoader.load(getClass().getResource("/view/SalaryManagementForm.fxml"));
        Scene scene = new Scene(anchorPane);
        Stage stage = new Stage();
        stage.setScene(scene);
        stage.setTitle("Salary Management");
        stage.setMaximized(true);
        stage.centerOnScreen();
        stage.show();
    }

    /*public void btnSaveOnAction(ActionEvent actionEvent) {
        String Empid = txtID.getText();
        String empName = txtName.getText();
        String contact = txtNumber.getText();
        String address = txtAddress.getText();
        String empRole = txtRole.getText();

                        try {
                            EmployeeModel employeeModel = new EmployeeModel();
                            boolean save = employeeModel.save(new EmployeeDTO(Empid, empName, contact, address, empRole));

                            if (save) {
                                new Alert(Alert.AlertType.INFORMATION, Empid + " Employee Added..!").show();
                                LoadAllCustomer();
                                btnClearOnAction();
                            } else {
                                new Alert(Alert.AlertType.ERROR, "Something Wrong..!").show();
                            }
                        } catch (SQLException | ClassNotFoundException e) {
                            new Alert(Alert.AlertType.ERROR, "The Employee ID already exists, So use different Employee Id").show();
                            e.printStackTrace();
                        }


    }*/


    public boolean empIdFormatValid(String empId) {
        String regex = "^e\\d+$";
        return empId.matches(regex);
    }

    public boolean roleValid(String role) {
        String regex = "^[a-zA-Z\\s\\-]+$";
        return role.matches(regex);
    }

    public boolean validName(String name) {
        // check if name is not null and matches the pattern "[a-zA-Z ]+"
        return name != null && name.matches("[a-zA-Z ]+");
    }

    private void btnClearOnAction() {
        txtID.clear();
        txtRole.clear();
        txtAddress.clear();
        txtNumber.clear();
        txtName.clear();

    }

    private void LoadAllCustomer() {
        tbl.getItems().clear();
        try {
            EmployeeModel employee = new EmployeeModel();
            ArrayList<EmployeeDTO> all = employee.getAll();
            for (EmployeeDTO tm : all) {

                tbl.getItems().add(
                        new EmployeeDTO(
                                tm.getId(),
                                tm.getName(),
                                tm.getContact(),
                                tm.getAddress(),
                                tm.getRole()
                        ));
            }

        } catch (SQLException | ClassNotFoundException e) {
            throw new RuntimeException(e);
        }

    }

    public void btnDeleteOnAction(ActionEvent actionEvent) {
        EmployeeModel emp = new EmployeeModel();
        try {
            boolean delete = emp.delete(txtID.getText());
            if (delete) {
                new Alert(Alert.AlertType.INFORMATION, " Employee Added..!").show();
                LoadAllCustomer();
                btnClearOnAction();
            } else {
                new Alert(Alert.AlertType.ERROR, "Something Wrong..!").show();
            }

        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    public void btnCSearchOnAction(ActionEvent actionEvent) {
        String id = txtID.getText();

        try {
            EmployeeModel employeeModek = new EmployeeModel();
            EmployeeDTO s1 = employeeModek.search(id);

//            ResultSet s1 = CrudUtil.crudUtil("SELECT*from employee where id=?", id);

            if (s1 != null) {
                txtName.setText(s1.getName());
                txtNumber.setText(s1.getContact());
                txtAddress.setText(s1.getAddress());
                txtRole.setText(s1.getRole());
            } else {
                new Alert(Alert.AlertType.ERROR, "Empty Result..!").show();
            }
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }

    }

    public void btnUpdateOnAction(ActionEvent actionEvent) {
        String id = txtID.getText();
        String text = txtName.getText();
        String contact = txtNumber.getText();
        String content = txtAddress.getText();
        String roal = txtRole.getText();

        try {
            EmployeeModel employeeModel = new EmployeeModel();
            boolean save = employeeModel.update(new EmployeeDTO(id, text, contact, content, roal));

            if (save) {
                new Alert(Alert.AlertType.INFORMATION, id + " Employee Added..!").show();
                LoadAllCustomer();
                btnClearOnAction();
            } else {
                new Alert(Alert.AlertType.ERROR, "Something Wrong..!").show();
            }
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    public void saveOnAction(ActionEvent actionEvent) {

        String Empid = txtID.getText();
        String empName = txtName.getText();
        String empContact = txtNumber.getText();
        String empAddress = txtAddress.getText();
        String empRole = txtRole.getText();


        if (EmployeeModel.validateEmployeeId(Empid)) {
            if (validName(empName)){
                if (roleValid(empRole)){
                    if (empIdFormatValid(Empid)){

                        try {
                            EmployeeModel employeeModel = new EmployeeModel();
                            boolean save = employeeModel.save(new EmployeeDTO(Empid, empName, empContact, empAddress, empRole));

                            if (save) {
                                new Alert(Alert.AlertType.INFORMATION,  " Employee Added..!").show();
                                LoadAllCustomer();
                                btnClearOnAction();
                            } else {
                                new Alert(Alert.AlertType.ERROR, "Something Wrong..!").show();
                            }
                        } catch (SQLException | ClassNotFoundException e) {
                            e.printStackTrace();
                        }

                    }else {
                        new Alert(Alert.AlertType.ERROR, "Invalid employee format").show();
                    }
                }else {
                    new Alert(Alert.AlertType.WARNING, "Invalid role format").show();
                }
            }else {
                new Alert(Alert.AlertType.WARNING, "Invalid employee name format").show();
            }
        }else {
            new Alert(Alert.AlertType.WARNING, "The Employee ID already exists, So use different Employee Id").show();
        }



    }

    public void empIdOnaction(ActionEvent actionEvent) {
        try {
            EmployeeDTO dto= EmployeeModel.search(txtID.getText());
            txtID.setText(dto.getId());
            txtRole.setText(dto.getRole());
            txtAddress.setText(dto.getAddress());
            txtNumber.setText(dto.getContact());
            txtName.setText(dto.getName());
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }

    }

    public void deleteOnAction(ActionEvent actionEvent) {
        try {
           if (EmployeeModel.delete(txtID.getText())){
               LoadAllCustomer();
               btnClearOnAction();
               new Alert(Alert.AlertType.INFORMATION,"Ok").show();
           }else {
               new Alert(Alert.AlertType.ERROR,"error").show();
           }
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    public void clearOnAction(ActionEvent actionEvent) {
        txtName.setText("");
        txtNumber.setText("");
        txtID.setText("");
        txtAddress.setText("");
        txtRole.setText("");
    }

    public void updateOnAction(ActionEvent actionEvent) {
        String id = txtID.getText();
        String text = txtName.getText();
        String contact = txtNumber.getText();
        String content = txtAddress.getText();
        String roal = txtRole.getText();

        try {

            if (EmployeeModel.update(new EmployeeDTO(id, text, contact, content, roal))) {
                new Alert(Alert.AlertType.INFORMATION, id + " Employee Added..!").show();
                LoadAllCustomer();
                btnClearOnAction();
            } else {
                new Alert(Alert.AlertType.ERROR, "Something Wrong..!").show();
            }
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}
