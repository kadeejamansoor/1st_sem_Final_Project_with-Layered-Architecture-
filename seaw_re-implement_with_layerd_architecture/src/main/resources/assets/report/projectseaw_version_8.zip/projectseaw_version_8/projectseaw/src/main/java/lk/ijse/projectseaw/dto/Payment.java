package lk.ijse.projectseaw.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString

public class Payment {
 private String   payment_id;
    private String          booking_id;
    private String   guest_id;
    private String           amount;
    private String   Payment_date;
    private String          payment_type;

}
