package lk.ijse.projectseaw.controller;

import com.jfoenix.controls.JFXButton;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import lk.ijse.projectseaw.dto.Stock;
import lk.ijse.projectseaw.dto.User;
import lk.ijse.projectseaw.dto.tm.StockTm;
import lk.ijse.projectseaw.dto.tm.UserTm;
import lk.ijse.projectseaw.model.StockModel;
import lk.ijse.projectseaw.model.UserModel;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import java.util.ResourceBundle;

public class Setting1FormController implements Initializable {
    public JFXButton dashboardbtn;
    public JFXButton bookingbtn;
    public JFXButton reservationbtn;
    public JFXButton roombtn;
    public JFXButton stockbtn;
    public JFXButton employeebtn;
    public JFXButton billingbtn;
    public JFXButton settingbtn;
    public JFXButton logoutbtn;

    public TableView tblUserSetting;
    public TableColumn colUsername;
    public TableColumn colPassword;

    public TextField txtUsername;
    public PasswordField txtPassword;

    @Override
    public void initialize(java.net.URL url, ResourceBundle resourceBundle) {
        setCellValueFactory();
        getAll();
    }

    private void setCellValueFactory() {
        colUsername.setCellValueFactory(new PropertyValueFactory<>("Username"));
        colPassword.setCellValueFactory(new PropertyValueFactory<>("Password"));
    }

    private void getAll() {
        try {
            ObservableList<UserTm> obList = FXCollections.observableArrayList();
            List<User> userList = UserModel.getAll();

            for (User user : userList) {
                obList.add(new UserTm(
                        user.getUsername(),
                        user.getPassword()
                ));
            }
            tblUserSetting.setItems(obList);
        } catch (SQLException e) {
            e.printStackTrace();
            new Alert(Alert.AlertType.ERROR, "SQL Error!").show();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    public void btnDashboardOnAction(ActionEvent actionEvent) throws IOException {
        Parent fxmlLoader = FXMLLoader.load(getClass().getResource("/view/DashBord.fxml"));
        Stage window = (Stage) dashboardbtn.getScene().getWindow();
        window.setScene(new Scene(fxmlLoader));
        window.setTitle("Dashboard");
        window.setMaximized(true);
        window.centerOnScreen();
    }

    public void btnBookingOnAction(ActionEvent actionEvent) throws IOException {
        Parent fxmlLoader = FXMLLoader.load(getClass().getResource("/view/BookingInformationForm.fxml"));
        Stage window = (Stage) bookingbtn.getScene().getWindow();
        window.setScene(new Scene(fxmlLoader));
        window.setTitle("Booking Management");
        window.setMaximized(true);
        window.centerOnScreen();
    }

    public void btnReservationOnAction(ActionEvent actionEvent) throws IOException {
        Parent fxmlLoader = FXMLLoader.load(getClass().getResource("/view/ReservationForm.fxml"));
        Stage window = (Stage) reservationbtn.getScene().getWindow();
        window.setScene(new Scene(fxmlLoader));
        window.setTitle("Reservation");
        window.setMaximized(true);
        window.centerOnScreen();
    }

    public void btnRoomOnAction(ActionEvent actionEvent) throws IOException {
        Parent fxmlLoader = FXMLLoader.load(getClass().getResource("/view/RoomManagementForm.fxml"));
        Stage window = (Stage) roombtn.getScene().getWindow();
        window.setScene(new Scene(fxmlLoader));
        window.setTitle("Room Management");
        window.setMaximized(true);
        window.centerOnScreen();
    }

    public void btnStockOnAction(ActionEvent actionEvent) throws IOException {
        Parent fxmlLoader = FXMLLoader.load(getClass().getResource("/view/StockManagementForm.fxml"));
        Stage window = (Stage) stockbtn.getScene().getWindow();
        window.setScene(new Scene(fxmlLoader));
        window.setTitle("Stock Management");
        window.setMaximized(true);
        window.centerOnScreen();
    }

    public void btnEmployeeOnAction(ActionEvent actionEvent) throws IOException {
        Parent fxmlLoader = FXMLLoader.load(getClass().getResource("/view/EmployeeManagementForm.fxml"));
        Stage window = (Stage) employeebtn.getScene().getWindow();
        window.setScene(new Scene(fxmlLoader));
        window.setTitle("Employee Management");
        window.setMaximized(true);
        window.centerOnScreen();
    }

    public void btnBillingOnAction(ActionEvent actionEvent) throws IOException {
        Parent fxmlLoader = FXMLLoader.load(getClass().getResource("/view/BillingForm.fxml"));
        Stage window = (Stage) billingbtn.getScene().getWindow();
        window.setScene(new Scene(fxmlLoader));
        window.setTitle("Billing");
        window.setMaximized(true);
        window.centerOnScreen();
    }

    public void btnSettingOnAction(ActionEvent actionEvent) throws IOException {
        Parent fxmlLoader = FXMLLoader.load(getClass().getResource("/view/Settings1From.fxml"));
        Stage window = (Stage) settingbtn.getScene().getWindow();
        window.setScene(new Scene(fxmlLoader));
        window.setTitle("Settings");
        window.setMaximized(true);
        window.centerOnScreen();
    }

    public void btnLogoutOnAction(ActionEvent actionEvent) throws IOException {
        Stage currentStage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        AnchorPane anchorPane = FXMLLoader.load(getClass().getResource("/view/LogOut.fxml"));
        Scene scene = new Scene(anchorPane);
        Stage stage = new Stage();
        stage.setScene(scene);
        stage.setTitle("Logout page");
        stage.setMaximized(true);
        stage.centerOnScreen();
        stage.show();
        currentStage.close();
    }

    public void btnUpdateOnAction(ActionEvent actionEvent) throws SQLException {
        String Username = txtUsername.getText();
        String Password = txtPassword.getText();

        boolean isUpdated = UserModel.update(Username, Password);
        new Alert(Alert.AlertType.CONFIRMATION, "User updated!").show();
    }

    public void btnDeleteOnAction(ActionEvent actionEvent) {
        String Username = txtUsername.getText();
        try {
            boolean isDeleted = UserModel.delete(Username);
            if (isDeleted) {
                new Alert(Alert.AlertType.CONFIRMATION, "deleted!").show();
            }
        } catch (SQLException e) {
            new Alert(Alert.AlertType.ERROR, "something went wrong!").show();
        }
    }

    public void btnSaveOnAction(ActionEvent actionEvent) {
        String Username = txtUsername.getText();
        String Password = txtPassword.getText();


        if (isUsernameValid(Username)) {
            if (passwordValid(Password)) {
                if (UserModel.validateUsernameANDpassword(Username)) {

                    User user = new User(Username, Password);
                    try {
                        boolean isSaved = UserModel.save(user);
                        if (isSaved) {
                            new Alert(Alert.AlertType.CONFIRMATION, "User saved!").show();
                        }
                    } catch (SQLException e) {
                        e.printStackTrace();
                        new Alert(Alert.AlertType.CONFIRMATION, "Something wrong").show();
                    }

                } else {
                    new Alert(Alert.AlertType.WARNING, "The Username already exists, So use different Username").show();
                }
            } else {
                Alert alert = new Alert(Alert.AlertType.ERROR, "Invalid passowrd. Please enter a valid username that contains only letters, digits, periods, underscores, and hyphens, and is at least 3 characters long.");
            }
        } else {
            Alert alert = new Alert(Alert.AlertType.ERROR, "Invalid username. Please enter a valid username that contains only letters, digits, periods, underscores, and hyphens, and is at least 3 characters long.");
        }


    }

    public boolean isUsernameValid(String username) {
        String usernameRegex = "^[a-zA-Z0-9._-]{3,}$"; // Allows letters, digits, periods, underscores, and hyphens. Must be at least 3 characters long.
        return username.matches(usernameRegex);
    }


    public boolean passwordValid(String password) {
        String passwordRegex = "^(?=.*[A-Za-z])(?=.*\\d)[A-Za-z\\d]{8,}$"; // Requires at least 1 letter, 1 digit, and must be at least 8 characters long.
        return password.matches(passwordRegex);
    }


    public void btnClearOnAction(ActionEvent actionEvent) {
        txtUsername.clear();
        txtPassword.clear();
    }
}
