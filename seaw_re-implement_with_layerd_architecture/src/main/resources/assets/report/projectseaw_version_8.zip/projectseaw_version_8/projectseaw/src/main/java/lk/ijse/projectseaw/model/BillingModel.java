package lk.ijse.projectseaw.model;

import lk.ijse.projectseaw.db.DBConnection;
import lk.ijse.projectseaw.dto.Billing;
import lk.ijse.projectseaw.dto.Stock;
import lk.ijse.projectseaw.dto.tm.BillingTm;
import lk.ijse.projectseaw.util.CrudUtil;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class BillingModel {

    public static List<Billing> getAll() throws SQLException, ClassNotFoundException {
        Connection con = DBConnection.getInstance().getConnection();
        String sql = "SELECT * FROM Payment";

        List<Billing> data = new ArrayList<>();

        ResultSet resultSet = con.createStatement().executeQuery(sql);
        while (resultSet.next()) {
            data.add(new Billing(
                    resultSet.getString(1),
                    resultSet.getString(2),
                    resultSet.getString(3),
                    resultSet.getDouble(4),
                    resultSet.getString(5)
            ));
        }
        return data;
    }

}
