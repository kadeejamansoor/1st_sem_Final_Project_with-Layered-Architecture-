package lk.ijse.projectseaw.controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import lk.ijse.projectseaw.dto.Booking;
import lk.ijse.projectseaw.dto.tm.BookingTm;
import lk.ijse.projectseaw.model.BookingModel;

import java.io.IOException;
import java.sql.*;
import java.time.LocalDate;
import java.util.List;
import java.util.Properties;
import java.util.ResourceBundle;

public class BookingManagementForm implements Initializable {
    private static final String URL = "jdbc:mysql://localhost:3306/Seew";
    private static final Properties props = new Properties();

    static {
        props.setProperty("user", "root");
        props.setProperty("password", "1234");
    }

    @FXML
    private ComboBox<String> cmbGuest;

    @FXML
    private ComboBox<String> cmbSelectRoom;

    @FXML
    private TableColumn<?, ?> colBookingid;

    @FXML
    private TableColumn<?, ?> colChecking;

    @FXML
    private TableColumn<?, ?> colCheckout;

    @FXML
    private TableColumn<?, ?> colGuest;

    @FXML
    private TableColumn<?, ?> colGuestId;

    @FXML
    private TableColumn<?, ?> colSelectroom;

    @FXML
    private DatePicker dtpkCheckin;

    @FXML
    private DatePicker dtpkCheckout;

    @FXML
    private TableView<BookingTm> tblBooking;

    @FXML
    private TextField txtBookingId;

    @FXML
    private TextField txtGuestId;

    @Override
    public void initialize(java.net.URL url, ResourceBundle resourceBundle) {
        setCellValueFactory();
        getAll();

        ObservableList<String> noOfGuestList = FXCollections.observableArrayList();
        noOfGuestList.add("1");
        noOfGuestList.add("2");
        noOfGuestList.add("3");
        noOfGuestList.add("4");
        noOfGuestList.add("5");
        cmbGuest.setItems(noOfGuestList);

        ObservableList<String> roomList = FXCollections.observableArrayList();
        roomList.add("R001");
        roomList.add("R002");
        roomList.add("R003");
        roomList.add("R004");
        roomList.add("R005");
        roomList.add("R006");
        roomList.add("R007");
        roomList.add("R008");
        roomList.add("R009");
        roomList.add("R010");
        cmbSelectRoom.setItems(roomList);
    }

    private void setCellValueFactory() {
        colBookingid.setCellValueFactory(new PropertyValueFactory<>("bookingId"));
        colChecking.setCellValueFactory(new PropertyValueFactory<>("BookingCheckIn"));
        colCheckout.setCellValueFactory(new PropertyValueFactory<>("BookingCheckOut"));
        colGuest.setCellValueFactory(new PropertyValueFactory<>("BookingGuests"));
        colSelectroom.setCellValueFactory(new PropertyValueFactory<>("BookingSelectRoom"));
        colGuestId.setCellValueFactory(new PropertyValueFactory<>("BookingGuestId"));
    }

    private void getAll() {
        try {
            ObservableList<BookingTm> obList = FXCollections.observableArrayList();
            List<Booking> bookingList = BookingModel.getAll();

            for (Booking booking : bookingList) {
                obList.add(new BookingTm(
                        booking.getBookingId(),
                        booking.getBookingCheckIn(),
                        booking.getBookingCheckOut(),
                        booking.getBookingGuests(),
                        booking.getBookingSelectRoom(),
                        booking.getBookingGuestId()
                ));
            }
            tblBooking.setItems(obList);
        } catch (SQLException e) {
            e.printStackTrace();
            new Alert(Alert.AlertType.ERROR, "SQL Error!").show();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    @FXML
    void btnClearOnAction(ActionEvent event) {
        txtBookingId.clear();
        //dtpkCheckin.clear();
        //dtpkCheckout.clear();
        //cmbGuest.clear();
        //cmbSelectRoom.Items.Clear();
        txtGuestId.clear();
    }

    @FXML
    void btnDeleteOnAction(ActionEvent event) throws SQLException {
        String BookingId = txtBookingId.getText();
        try (Connection con = DriverManager.getConnection(URL, props)) {
            String sql = "DELETE FROM Booking WHERE booking_id = ?";

            PreparedStatement pstm = con.prepareStatement(sql);
            pstm.setString(1, BookingId);

            if (pstm.executeUpdate() > 0) {
                new Alert(Alert.AlertType.CONFIRMATION, "deleted!").show();
            }
        }
    }

    @FXML
    void btnGuestManagementOnAction(ActionEvent event) throws IOException {
        AnchorPane anchorPane = FXMLLoader.load(getClass().getResource("/view/GuestManagementForm.fxml"));
        Scene scene = new Scene(anchorPane);
        Stage stage = new Stage();
        stage.setScene(scene);
        stage.setTitle("Guest Management");
        stage.setMaximized(true);
        stage.centerOnScreen();
        stage.show();
    }

    @FXML
    void btnUpdateOnAction(ActionEvent event) throws SQLException {
        String BookingId = txtBookingId.getText();
        LocalDate Checkin = dtpkCheckin.getValue();
        LocalDate Checkout = dtpkCheckout.getValue();
        int Guest = Integer.parseInt(cmbGuest.getValue().toString());
        String SelectRoom = cmbSelectRoom.getValue().toString();
        String GuestId = txtGuestId.getText();

        /*try (Connection con = DriverManager.getConnection(URL, props)) {
            String sql = "UPDATE Booking SET check_in = ?, check_out = ?, no_of_guest = ?, select_room = ?, guest_id = ? WHERE booking_id = ?";
            PreparedStatement pstm = con.prepareStatement(sql);
            pstm.setDate(1, Date.valueOf(Checkin));
            pstm.setDate(2, Date.valueOf(Checkout));
            pstm.setInt(3, Guest);
            pstm.setString(4, SelectRoom);
            pstm.setString(5, GuestId);
            pstm.setString(6, BookingId);

            boolean isUpdated = pstm.executeUpdate() > 0;
            if (isUpdated) {
                new Alert(Alert.AlertType.CONFIRMATION, "updated!!").show();
            }
        }*/



        if (BookingInformationFormController.validateBookingIdFormat(BookingId)) {
            try (Connection con = DriverManager.getConnection(URL, props)) {
                String sql = "UPDATE Booking SET check_in = ?, check_out = ?, no_of_guest = ?, select_room = ?, guest_id = ? WHERE booking_id = ?";
                PreparedStatement pstm = con.prepareStatement(sql);
                pstm.setDate(1, Date.valueOf(Checkin));
                pstm.setDate(2, Date.valueOf(Checkout));
                pstm.setInt(3, Guest);
                pstm.setString(4, SelectRoom);
                pstm.setString(5, GuestId);
                pstm.setString(6, BookingId);

                boolean isUpdated = pstm.executeUpdate() > 0;
                if (isUpdated) {
                    new Alert(Alert.AlertType.CONFIRMATION, "updated!!").show();
                }
            }
        } else {
            new Alert(Alert.AlertType.WARNING, "Invalid booking id format. Please enter valid id!").show();
        }


    }

    @FXML
    void codeSearchOnAction(ActionEvent event) throws SQLException {
        String BookingId = txtBookingId.getText();

        try (Connection con = DriverManager.getConnection(URL, props)) {
            String sql = "SELECT * FROM Booking WHERE booking_id = ?";
            PreparedStatement pstm = con.prepareStatement(sql);
            pstm.setString(1, BookingId);

            ResultSet resultSet = pstm.executeQuery();
            if (resultSet.next()) {
                String Booking_Id = resultSet.getString(1);
                String Check_in = resultSet.getString(2);
                String Check_out = resultSet.getString(3);
                int num = resultSet.getInt(4);
                String Guest_SelectRoom = resultSet.getString(5);
                String Guest_BookingId = resultSet.getString(6);

                txtBookingId.setText(Booking_Id);
                dtpkCheckin.setValue(LocalDate.parse(Check_in));
                dtpkCheckout.setValue(LocalDate.parse(Check_out));
                //cmbGuest.setSelectedItem(numOf_Guest);
                //cmbSelectRoom.setSelectedItem(Guest_SelectRoom);
                txtGuestId.setText(Guest_BookingId);
            }
        }

    }
}
