package lk.ijse.projectseaw.controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import lk.ijse.projectseaw.dto.tm.SalaryTm;
import lk.ijse.projectseaw.model.SalaryModel;

import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;

public class SalaryManagmentController implements Initializable {
    public TableColumn fulName;
    public TableColumn amount;
    public TableColumn month;
    public TableColumn emp_id;
    public TableView tbl;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        setTableProperty();
        setTableData();
    }
    ObservableList<SalaryTm> list= FXCollections.observableArrayList();

    private void setTableData() {
        try {
            ArrayList<SalaryTm>data= SalaryModel.getAllData();
            for (int i = 0; i < data.size(); i++) {
                list.add(data.get(i));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    private void setTableProperty() {
        emp_id.setCellValueFactory(new PropertyValueFactory<>("empId"));
        amount.setCellValueFactory(new PropertyValueFactory<>("amountTm"));
        month.setCellValueFactory(new PropertyValueFactory<>("date"));
        fulName.setCellValueFactory(new PropertyValueFactory<>("fullNAme"));
        tbl.setItems(list);
    }


}
