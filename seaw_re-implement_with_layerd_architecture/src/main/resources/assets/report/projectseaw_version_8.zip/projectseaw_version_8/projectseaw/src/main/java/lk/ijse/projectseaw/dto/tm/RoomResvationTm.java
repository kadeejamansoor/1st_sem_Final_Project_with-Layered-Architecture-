package lk.ijse.projectseaw.dto.tm;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString

public class RoomResvationTm {
    private String reservationId;
    private String roomType;
    private String roomId;

}
