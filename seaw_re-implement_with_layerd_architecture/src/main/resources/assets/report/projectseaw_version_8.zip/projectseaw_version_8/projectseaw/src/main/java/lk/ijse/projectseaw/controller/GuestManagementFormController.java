package lk.ijse.projectseaw.controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import lk.ijse.projectseaw.dto.Guest;
import lk.ijse.projectseaw.dto.tm.GuestTm;
import lk.ijse.projectseaw.model.BookingModel;
import lk.ijse.projectseaw.model.GuestModel;

import java.sql.*;
import java.util.List;
import java.util.Properties;
import java.util.ResourceBundle;

//import static lk.ijse.projectseaw.controller.BookingInformationFormController.*;

public class GuestManagementFormController implements Initializable {
    private static final String URL = "jdbc:mysql://localhost:3306/Seew";
    private static final Properties props = new Properties();

    static {
        props.setProperty("user", "root");
        props.setProperty("password", "1234");
    }

    @FXML
    private TableColumn<?, ?> colAddress;

    @FXML
    private TableColumn<?, ?> colAge;

    @FXML
    private TableColumn<?, ?> colCountry;

    @FXML
    private TableColumn<?, ?> colGuestCity;

    @FXML
    private TableColumn<?, ?> colGuestFullName;

    @FXML
    private TableColumn<?, ?> colGuestId;

    @FXML
    private TableColumn<?, ?> colPostalCode;

    @FXML
    private TableColumn<?, ?> colState;

    @FXML
    private TableView<GuestTm> tblGuest;

    @FXML
    private TextField txtAddress;

    @FXML
    private TextField txtAge;

    @FXML
    private TextField txtCity;

    @FXML
    private TextField txtCountry;

    @FXML
    private static TextField txtGuestFullName;

    @FXML
    private TextField txtGuestId;

    @FXML
    private TextField txtPostalCode;

    @FXML
    private TextField txtState;

    @Override
    public void initialize(java.net.URL url, ResourceBundle resourceBundle) {
        setCellValueFactory();
        getAll();
    }

    private void setCellValueFactory() {
        colGuestId.setCellValueFactory(new PropertyValueFactory<>("GuestId"));
        colGuestFullName.setCellValueFactory(new PropertyValueFactory<>("GuestFullname"));
        colAddress.setCellValueFactory(new PropertyValueFactory<>("GuestAddress"));
        colGuestCity.setCellValueFactory(new PropertyValueFactory<>("GuestCity"));
        colPostalCode.setCellValueFactory(new PropertyValueFactory<>("GuestPostalcode"));
        colCountry.setCellValueFactory(new PropertyValueFactory<>("GuestCountry"));
        colState.setCellValueFactory(new PropertyValueFactory<>("GuestState"));
        colAge.setCellValueFactory(new PropertyValueFactory<>("GuestAge"));
    }

    private void getAll() {
        try {
            ObservableList<GuestTm> obList = FXCollections.observableArrayList();
            List<Guest> guestList = GuestModel.getAll();

            for (Guest guest : guestList) {
                obList.add(new GuestTm(
                        guest.getGuestId(),
                        guest.getFullname(),
                        guest.getAddress(),
                        guest.getCity(),
                        guest.getPostalcode(),
                        guest.getCountry(),
                        guest.getState(),
                        guest.getAge()
                ));
            }
            tblGuest.setItems(obList);
        } catch (SQLException e) {
            e.printStackTrace();
            new Alert(Alert.AlertType.ERROR, "SQL Error!").show();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    @FXML
    void btnClearOnAction(ActionEvent event) {
        txtGuestId.clear();
        txtGuestFullName.clear();
        txtAddress.clear();
        txtCity.clear();
        txtPostalCode.clear();
        txtCountry.clear();
        txtState.clear();
        txtAge.clear();
    }

    @FXML
    void btnDeleteOnAction(ActionEvent event) throws SQLException {
        String GuestId = txtGuestId.getText();
        try (Connection con = DriverManager.getConnection(URL, props)) {
            String sql = "DELETE FROM Guest WHERE guest_id = ?";

            PreparedStatement pstm = con.prepareStatement(sql);
            pstm.setString(1, GuestId);

            if (pstm.executeUpdate() > 0) {
                new Alert(Alert.AlertType.CONFIRMATION, "deleted!").show();
            }
        }
    }

    @FXML
    public void btnUpdateOnAction(ActionEvent event) throws SQLException {
        String GuestId = txtGuestId.getText();
        String GuestFullName = txtGuestFullName.getText();
        String Address = txtAddress.getText();
        String City = txtCity.getText();
        String PostalCode = txtPostalCode.getText();
        String Country = txtCountry.getText();
        String State = txtState.getText();
        int Age = Integer.parseInt(txtAge.getText());

        try (Connection con = DriverManager.getConnection(URL, props)) {
            String sql = "UPDATE Guest SET guest_Fullname = ?, address = ?, city = ?, postal_code = ?, country = ?, state = ?, age = ? WHERE guest_id = ?";
            PreparedStatement pstm = con.prepareStatement(sql);
            pstm.setString(1, GuestFullName);
            pstm.setString(2, Address);
            pstm.setString(3, City);
            pstm.setString(4, PostalCode);
            pstm.setString(5, Country);
            pstm.setString(6, State);
            pstm.setString(7, String.valueOf(Age));
            pstm.setString(8, GuestId);

            boolean isUpdated = pstm.executeUpdate() > 0;
            if (isUpdated) {
                new Alert(Alert.AlertType.CONFIRMATION, "yes! updated!!").show();
            }
        }
    }

    @FXML
    void codeSearchOnAction(ActionEvent event) throws SQLException {
        String GuestId = txtGuestId.getText();

        try (Connection con = DriverManager.getConnection(URL, props)) {
            String sql = "SELECT * FROM Guest WHERE guest_id = ?";
            PreparedStatement pstm = con.prepareStatement(sql);
            pstm.setString(1, GuestId);

            ResultSet resultSet = pstm.executeQuery();
            if (resultSet.next()) {
                String Guest_Id = resultSet.getString(1);
                String Gues_tFullName = resultSet.getString(2);
                String Guest_Address = resultSet.getString(3);
                String Guest_City = resultSet.getString(4);
                String Guest_PostalCode = resultSet.getString(5);
                String Guest_Country = resultSet.getString(6);
                String Guest_State = resultSet.getString(7);
                String Guest_Age = resultSet.getString(8);

                txtGuestId.setText(Guest_Id);
                txtGuestFullName.setText(Gues_tFullName);
                txtAddress.setText(Guest_Address);
                txtCity.setText(Guest_City);
                txtPostalCode.setText(Guest_PostalCode);
                txtCountry.setText(Guest_Country);
                txtState.setText(Guest_State);
                txtAge.setText(Guest_Age);
            }
        }

    }
}
