package lk.ijse.projectseaw.controller;


import javafx.event.ActionEvent;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;

import java.net.URL;
import java.time.LocalDate;
import java.util.ResourceBundle;


public class PaymentConfirmationFormController {

    public static Label lblGuesdId;
    public static Label lblFullName;
    public static Label lblAddress;
    public static Label lblCity;
    public static Label lblPostalCode;
    public static Label lblCountry;
    public static Label lblState;
    public static Label lblAge;
    
    public static Label lblBookingId;
    public static Label lblCheckIn;
    public static Label lblCheckOut;
    public static Label lblSelectRoom;
    public static Label lblGuest;
    public static Label lblGuestId;





    public void btnPayOnAction(ActionEvent actionEvent) {
    }


}
