package lk.ijse.projectseaw.model;

import javafx.scene.control.Alert;
import lk.ijse.projectseaw.db.DBConnection;
import lk.ijse.projectseaw.dto.Booking;
import lk.ijse.projectseaw.dto.Guest;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

public class BookingModel {
    private static final String URL = "jdbc:mysql://localhost:3306/seew";
    private static final Properties props = new Properties();

    static {
        props.setProperty("user", "root");
        props.setProperty("password", "1234");
    }

    public static List<Booking> getAll() throws SQLException, ClassNotFoundException {
        Connection con = DBConnection.getInstance().getConnection();
        String sql = "SELECT * FROM Booking";

        List<Booking> data = new ArrayList<>();

        ResultSet resultSet = con.createStatement().executeQuery(sql);
        while (resultSet.next()) {
            data.add(new Booking(
                    resultSet.getString(1),
                    resultSet.getString(2),
                    resultSet.getString(3),
                    resultSet.getInt(4),
                    resultSet.getString(5),
                    resultSet.getString(6)
            ));
        }
        return data;
    }


    public static boolean validateGuestId(String guestId) {
        try (Connection con = DriverManager.getConnection(URL, props)) {
            String query = "SELECT guest_id FROM Guest WHERE guest_id = ?";
            PreparedStatement pstm = con.prepareStatement(query);
            pstm.setString(1, guestId);
            ResultSet rs = pstm.executeQuery();
            return !rs.next();
        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }
    }

    public static boolean validateBookingId(String bookingId) {
        try (Connection con = DriverManager.getConnection(URL, props)) {
            String query = "SELECT booking_id FROM Booking WHERE booking_id = ?";
            PreparedStatement pstm = con.prepareStatement(query);
            pstm.setString(1, bookingId);
            ResultSet rs = pstm.executeQuery();
            return !rs.next();
        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }
    }

    public static boolean validateAvailableGuestId(String guestId) {
        try (Connection con = DriverManager.getConnection(URL, props)) {
            String query = "SELECT guest_id FROM Guest WHERE guest_id = ?";
            PreparedStatement pstm = con.prepareStatement(query);
            pstm.setString(1, guestId);
            ResultSet rs = pstm.executeQuery();
            return rs.next(); // returns true if the guest_id exists in the database
        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }
    }

}
