package lk.ijse.projectseaw.model;

import lk.ijse.projectseaw.db.DBConnection;
import lk.ijse.projectseaw.dto.Stock;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

public class StockModel {
    private static final String URL = "jdbc:mysql://localhost:3306/seew";
    private static final Properties props = new Properties();

    static {
        props.setProperty("user", "root");
        props.setProperty("password", "1234");
    }

    public static List<Stock> getAll() throws SQLException, ClassNotFoundException {
        Connection con = DBConnection.getInstance().getConnection();
        String sql = "SELECT * FROM Stock";

        List<Stock> data = new ArrayList<>();

        ResultSet resultSet = con.createStatement().executeQuery(sql);
        while (resultSet.next()) {
            data.add(new Stock(
                    resultSet.getString(1),
                    resultSet.getString(2),
                    resultSet.getInt(3)
            ));
        }
        return data;
    }

    public static boolean save(Stock stock) throws SQLException {
        try (Connection con = DriverManager.getConnection(URL, props)) {
            String sql = "INSERT INTO Stock(stock_id, stock_name, quantity) " +
                    "VALUES(?, ?, ?)";

            PreparedStatement pstm = con.prepareStatement(sql);
            pstm.setString(1, stock.getStockId());
            pstm.setString(2, stock.getStockName());
            pstm.setInt(3, stock.getQuantity());

            return pstm.executeUpdate() > 0;
        }
    }


    public static boolean update(String stockId, String stockName, int qty) throws SQLException {
        try (Connection con = DriverManager.getConnection(URL, props)) {
            String sql = "UPDATE Stock SET stock_name = ?,  " + "quantity = ? WHERE stock_id = ?";
            PreparedStatement pstm = con.prepareStatement(sql);
            pstm.setString(1, stockName);
            pstm.setInt(2, qty);
            pstm.setString(3, stockId);

            return pstm.executeUpdate() > 0;

        }
    }

    public static Stock search(String stockId) throws SQLException{
        try (Connection con = DBConnection.getInstance().getConnection()) {
            String sql = "SELECT * FROM Stock WHERE stock_id = ?";
            PreparedStatement pstm = con.prepareStatement(sql);
            pstm.setString(1, stockId);

            ResultSet resultSet = pstm.executeQuery();
            if(resultSet.next()) {
                return new Stock(
                        resultSet.getString(1),
                        resultSet.getString(2),
                        resultSet.getInt(3)
                );
            }

        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static boolean delete(String stockId) throws SQLException {
        try (Connection con = DriverManager.getConnection(URL, props)) {
            String sql = "DELETE FROM Stock WHERE stock_id = ?";
            PreparedStatement pstm = con.prepareStatement(sql);
            pstm.setString(1, stockId);

            return pstm.executeUpdate() > 0;
        }
    }

    public static boolean validateStockId(String stockId) {
        try (Connection con = DriverManager.getConnection(URL, props)) {
            String query = "SELECT Stock FROM Stock WHERE stock_id = ?";
            PreparedStatement pstm = con.prepareStatement(query);
            pstm.setString(1, stockId);
            ResultSet rs = pstm.executeQuery();
            return !rs.next();
        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }
    }

}
